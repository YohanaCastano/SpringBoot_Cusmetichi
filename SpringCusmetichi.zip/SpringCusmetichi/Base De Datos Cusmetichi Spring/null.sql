-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 18-03-2024 a las 08:01:26
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `null`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `nombre_categoria` varchar(45) DEFAULT NULL,
  `fkid_producto` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `nombre_categoria`, `fkid_producto`) VALUES
(1, 'Herbacol', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `apellido_cliente` varchar(45) DEFAULT NULL,
  `direccion_cliente` varchar(45) DEFAULT NULL,
  `email_cliente` varchar(45) DEFAULT NULL,
  `identificacion_cliente` bigint(20) DEFAULT NULL,
  `nombre_cliente` varchar(45) DEFAULT NULL,
  `tel_cliente` bigint(20) DEFAULT NULL,
  `fkid_producto` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id`, `apellido_cliente`, `direccion_cliente`, `email_cliente`, `identificacion_cliente`, `nombre_cliente`, `tel_cliente`, `fkid_producto`) VALUES
(1, 'Castaño', 'cra81J45-12 ', 'yohanamildred@hotmail.com', 1012000222, 'Yohana', 3013478, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compra_proveedor`
--

CREATE TABLE `compra_proveedor` (
  `id` int(11) NOT NULL,
  `cantidad_producto` int(11) DEFAULT NULL,
  `costo_producto` double DEFAULT NULL,
  `estado_pedido` varchar(45) DEFAULT NULL,
  `fecha_pedido` date DEFAULT NULL,
  `fkid_empleado` int(11) DEFAULT NULL,
  `fkid_proveedor` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `compra_proveedor`
--

INSERT INTO `compra_proveedor` (`id`, `cantidad_producto`, `costo_producto`, `estado_pedido`, `fecha_pedido`, `fkid_empleado`, `fkid_proveedor`) VALUES
(1, 150, 700000, 'En Revision', '2024-02-28', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleados`
--

CREATE TABLE `empleados` (
  `id` int(11) NOT NULL,
  `apellido_empleado` varchar(45) DEFAULT NULL,
  `email_empleados` varchar(45) DEFAULT NULL,
  `nombre_empleado` varchar(45) DEFAULT NULL,
  `identificacion_empleado` bigint(20) DEFAULT NULL,
  `tel_empleados` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `empleados`
--

INSERT INTO `empleados` (`id`, `apellido_empleado`, `email_empleados`, `nombre_empleado`, `identificacion_empleado`, `tel_empleados`) VALUES
(1, 'Diaz', 'carlosdiaz01@gmail.com', 'Mia', 1023026730, 3133236871),
(2, 'Ortiz', 'lacampos03@misena.edu.co', 'Carlota', 1023026730, 3133236871),
(3, 'Ortiz', 'lacampos03@misena.edu.co', 'Carlota', 1023026730, 3133236871),
(4, 'Ortiz', 'lacampos03@misena.edu.co', 'Carlota', 1023026730, 3133236871),
(5, 'Ortiz', 'lacampos03@misena.edu.co', 'Carlota', 1023026730, 3133236871);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entradas`
--

CREATE TABLE `entradas` (
  `id` int(11) NOT NULL,
  `cantidad_entrada` int(11) DEFAULT NULL,
  `fecha_entrada` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `entradas`
--

INSERT INTO `entradas` (`id`, `cantidad_entrada`, `fecha_entrada`) VALUES
(1, 150, '2024-03-04'),
(2, 105, '2024-02-07'),
(3, 105, '2024-02-07'),
(4, 105, '2024-02-07'),
(5, 105, '2024-02-07');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventarios`
--

CREATE TABLE `inventarios` (
  `id` int(11) NOT NULL,
  `cantidad_producto` int(11) DEFAULT NULL,
  `fkid_input` int(11) DEFAULT NULL,
  `fkid_output` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `inventarios`
--

INSERT INTO `inventarios` (`id`, `cantidad_producto`, `fkid_input`, `fkid_output`) VALUES
(1, 230, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `marcas`
--

CREATE TABLE `marcas` (
  `id` int(11) NOT NULL,
  `nombre_marca` varchar(45) DEFAULT NULL,
  `fkid_producto` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `marcas`
--

INSERT INTO `marcas` (`id`, `nombre_marca`, `fkid_producto`) VALUES
(1, 'Hola', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `cantidad_producto` int(11) DEFAULT NULL,
  `descripcion_producto` varchar(45) DEFAULT NULL,
  `iva_producto` double DEFAULT NULL,
  `nombre_producto` varchar(45) DEFAULT NULL,
  `precio_producto` double DEFAULT NULL,
  `stock_producto` int(11) DEFAULT NULL,
  `sub_total` double DEFAULT NULL,
  `tamaño_producto` varchar(45) DEFAULT NULL,
  `fkid_inventario` int(11) DEFAULT NULL,
  `fkid_proveedor` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `cantidad_producto`, `descripcion_producto`, `iva_producto`, `nombre_producto`, `precio_producto`, `stock_producto`, `sub_total`, `tamaño_producto`, `fkid_inventario`, `fkid_proveedor`) VALUES
(1, 50, 'Tratamiento control caida', 0.19, 'Tratamiento Capilar', 28000, 80, 0, '250ml', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `id` int(11) NOT NULL,
  `apellido_proveedor` varchar(45) DEFAULT NULL,
  `email_proveedor` varchar(45) DEFAULT NULL,
  `empresa_proveedor` varchar(45) DEFAULT NULL,
  `identificacion_proveedor` bigint(20) DEFAULT NULL,
  `nombre_proveedor` varchar(45) DEFAULT NULL,
  `telefono_proveedor` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`id`, `apellido_proveedor`, `email_proveedor`, `empresa_proveedor`, `identificacion_proveedor`, `nombre_proveedor`, `telefono_proveedor`) VALUES
(1, 'Paz', 'nancypaz05@gmail.com', 'Herbacol', 1022978031, 'Nancy', 3108652082),
(2, 'Rios', 'marlonrios@hotmail.com', 'Masglo', 1214785412, 'Marlon', 3114125896),
(3, 'Boada', 'odioponeremails@gmail.com', 'Herbacol', 1022978031, 'Ramiro', 3108652082),
(4, 'Boada', 'odioponeremails@gmail.com', 'Herbacol', 1022978031, 'Ramiro', 3108652082),
(5, 'Boada', 'odioponeremails@gmail.com', 'Herbacol', 1022978031, 'Ramiro', 3108652082),
(6, 'Boada', 'odioponeremails@gmail.com', 'Herbacol', 1022978031, 'Ramiro', 3108652082);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol`
--

CREATE TABLE `rol` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `rol`
--

INSERT INTO `rol` (`id`, `nombre`) VALUES
(1, 'Cliente'),
(2, 'Cliente'),
(3, 'Gerente'),
(4, 'Cliente'),
(5, 'Gerente'),
(6, 'Gerente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sale_product`
--

CREATE TABLE `sale_product` (
  `fkid_ventas` int(11) NOT NULL,
  `fkid_producto` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `salidas`
--

CREATE TABLE `salidas` (
  `id` int(11) NOT NULL,
  `cantidad_salidas` int(11) DEFAULT NULL,
  `fecha_salida` date DEFAULT NULL,
  `iva_total` double DEFAULT NULL,
  `metodo_pago` varchar(255) DEFAULT NULL,
  `tipo_salida` varchar(45) DEFAULT NULL,
  `fkid_empleado` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `salidas`
--

INSERT INTO `salidas` (`id`, `cantidad_salidas`, `fecha_salida`, `iva_total`, `metodo_pago`, `tipo_salida`, `fkid_empleado`) VALUES
(1, 50, '2024-02-28', 0.19, 'Daviplata', 'En Proceso', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `contraseña` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `fkid_cliente` int(11) DEFAULT NULL,
  `fkid_empleado` int(11) DEFAULT NULL,
  `fkid_rol` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `contraseña`, `email`, `nombre`, `fkid_cliente`, `fkid_empleado`, `fkid_rol`) VALUES
(1, 'Carla12', 'carlaEmpleada@gmail.com', 'EmpleadaCarla', 1, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `id` int(11) NOT NULL,
  `iva_total` double DEFAULT NULL,
  `metodo_pago` varchar(45) DEFAULT NULL,
  `fkid_empleado` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`id`, `iva_total`, `metodo_pago`, `fkid_empleado`) VALUES
(1, 0.19, 'Nequi', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKwf3c7ywkxo7yndotgwkahtmj` (`fkid_producto`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKeoh3bbwxtkvooftr3ulhu0kq1` (`fkid_producto`);

--
-- Indices de la tabla `compra_proveedor`
--
ALTER TABLE `compra_proveedor`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKen4c41ykwo6f5xqi1sv7xncnq` (`fkid_empleado`),
  ADD KEY `FKn47brgqummsx0pis8xh4jos1e` (`fkid_proveedor`);

--
-- Indices de la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `entradas`
--
ALTER TABLE `entradas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `inventarios`
--
ALTER TABLE `inventarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKp9k849ix2ixqyhoehwdprwixn` (`fkid_input`),
  ADD KEY `FKnu7fpgiksqubxwjs613vg1emc` (`fkid_output`);

--
-- Indices de la tabla `marcas`
--
ALTER TABLE `marcas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKio3hnkr2rcpxvmump76hqjo44` (`fkid_producto`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKot5gn90dcnj8209pyqlsyo6ex` (`fkid_inventario`),
  ADD KEY `FKij4rrko8d2qulwdbacksxy0dv` (`fkid_proveedor`);

--
-- Indices de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `rol`
--
ALTER TABLE `rol`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `sale_product`
--
ALTER TABLE `sale_product`
  ADD KEY `FK42iis64kscy1hn4bb3sqn5ods` (`fkid_producto`),
  ADD KEY `FK1vcshf00nn3s2hqxj1v6jltge` (`fkid_ventas`);

--
-- Indices de la tabla `salidas`
--
ALTER TABLE `salidas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK64hfocliu4nw41ngfu2o5otf6` (`fkid_empleado`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK17we1ymlh8mcmvnu7spvomb3q` (`fkid_cliente`),
  ADD KEY `FKei02v7c48kk760u04kbo8pgab` (`fkid_empleado`),
  ADD KEY `FKl1t1wrik8cehyv5ryxpikurdl` (`fkid_rol`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKennt5fy642ooeqtqcd90809jp` (`fkid_empleado`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `compra_proveedor`
--
ALTER TABLE `compra_proveedor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `empleados`
--
ALTER TABLE `empleados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `entradas`
--
ALTER TABLE `entradas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `inventarios`
--
ALTER TABLE `inventarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `marcas`
--
ALTER TABLE `marcas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `rol`
--
ALTER TABLE `rol`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `salidas`
--
ALTER TABLE `salidas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD CONSTRAINT `FKwf3c7ywkxo7yndotgwkahtmj` FOREIGN KEY (`fkid_producto`) REFERENCES `productos` (`id`);

--
-- Filtros para la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD CONSTRAINT `FKeoh3bbwxtkvooftr3ulhu0kq1` FOREIGN KEY (`fkid_producto`) REFERENCES `productos` (`id`);

--
-- Filtros para la tabla `compra_proveedor`
--
ALTER TABLE `compra_proveedor`
  ADD CONSTRAINT `FKen4c41ykwo6f5xqi1sv7xncnq` FOREIGN KEY (`fkid_empleado`) REFERENCES `empleados` (`id`),
  ADD CONSTRAINT `FKn47brgqummsx0pis8xh4jos1e` FOREIGN KEY (`fkid_proveedor`) REFERENCES `proveedores` (`id`);

--
-- Filtros para la tabla `inventarios`
--
ALTER TABLE `inventarios`
  ADD CONSTRAINT `FKnu7fpgiksqubxwjs613vg1emc` FOREIGN KEY (`fkid_output`) REFERENCES `salidas` (`id`),
  ADD CONSTRAINT `FKp9k849ix2ixqyhoehwdprwixn` FOREIGN KEY (`fkid_input`) REFERENCES `entradas` (`id`);

--
-- Filtros para la tabla `marcas`
--
ALTER TABLE `marcas`
  ADD CONSTRAINT `FKio3hnkr2rcpxvmump76hqjo44` FOREIGN KEY (`fkid_producto`) REFERENCES `productos` (`id`);

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `FKij4rrko8d2qulwdbacksxy0dv` FOREIGN KEY (`fkid_proveedor`) REFERENCES `proveedores` (`id`),
  ADD CONSTRAINT `FKot5gn90dcnj8209pyqlsyo6ex` FOREIGN KEY (`fkid_inventario`) REFERENCES `inventarios` (`id`);

--
-- Filtros para la tabla `sale_product`
--
ALTER TABLE `sale_product`
  ADD CONSTRAINT `FK1vcshf00nn3s2hqxj1v6jltge` FOREIGN KEY (`fkid_ventas`) REFERENCES `ventas` (`id`),
  ADD CONSTRAINT `FK42iis64kscy1hn4bb3sqn5ods` FOREIGN KEY (`fkid_producto`) REFERENCES `productos` (`id`);

--
-- Filtros para la tabla `salidas`
--
ALTER TABLE `salidas`
  ADD CONSTRAINT `FK64hfocliu4nw41ngfu2o5otf6` FOREIGN KEY (`fkid_empleado`) REFERENCES `empleados` (`id`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `FK17we1ymlh8mcmvnu7spvomb3q` FOREIGN KEY (`fkid_cliente`) REFERENCES `clientes` (`id`),
  ADD CONSTRAINT `FKei02v7c48kk760u04kbo8pgab` FOREIGN KEY (`fkid_empleado`) REFERENCES `empleados` (`id`),
  ADD CONSTRAINT `FKl1t1wrik8cehyv5ryxpikurdl` FOREIGN KEY (`fkid_rol`) REFERENCES `rol` (`id`);

--
-- Filtros para la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD CONSTRAINT `FKennt5fy642ooeqtqcd90809jp` FOREIGN KEY (`fkid_empleado`) REFERENCES `empleados` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
