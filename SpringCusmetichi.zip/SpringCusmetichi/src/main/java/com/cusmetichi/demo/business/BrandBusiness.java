package com.cusmetichi.demo.business;
import com.cusmetichi.demo.dtos.*;
import com.cusmetichi.demo.entity.*;
import com.cusmetichi.demo.service.BrandService;
import com.cusmetichi.demo.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.List;

@Component
public class BrandBusiness {

    @Autowired
    private BrandService brandService;

    @Autowired
    private ProductService productService;

    private List<Brand> brandList;


    // Metodo GET
    public List<BrandDto> findAll() throws Exception {
        this.brandList = this.brandService.findAll();
        List<BrandDto> brandDtoList = new ArrayList<>();
        this.brandList.stream().forEach(brand -> {
            BrandDto brandDto = new BrandDto();
            brandDto.setId(brand.getId());
            brandDto.setNombreMarca(brand.getNombreMarca());

            brandDtoList.add(brandDto);

        });
        return brandDtoList;
    }

    // Metodo POST
    public void createBrand(BrandDto brandDto) throws Exception {
        Brand brand = new Brand();
        brand.setNombreMarca(brandDto.getNombreMarca());


        this.brandService.create(brand);

        int brandId = brand.getId();
        brandDto.setId(brandId);

    }

   // Metodo PUT
    public void updatedBrand(int id, BrandDto updatedBrandDto) throws Exception {
        Brand existingBrand = brandService.findById(id);
        
        //Por si la marca no existe
        if (existingBrand == null) {
            throw new Exception("Brand not found with id: " + id);
        }
        existingBrand.setNombreMarca(updatedBrandDto.getNombreMarca());

        this.brandService.update(existingBrand);

    }

    // Metodo DELETE
    public void deleteBrand(int id) throws Exception {
        Brand existingBrand = brandService.findById(id);
        if (existingBrand == null) {
            throw new Exception("Customer not found with id: " + id);
        }
        existingBrand.setEliminado(true);
        brandService.update(existingBrand);
    }
}



