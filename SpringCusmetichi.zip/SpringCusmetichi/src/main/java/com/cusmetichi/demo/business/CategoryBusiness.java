package com.cusmetichi.demo.business;
import com.cusmetichi.demo.dtos.*;
import com.cusmetichi.demo.entity.*;
import com.cusmetichi.demo.service.CategoryService;
import com.cusmetichi.demo.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.List;

@Component
public class CategoryBusiness {
    @Autowired
    private CategoryService categoryService;
    @Autowired
    private ProductService productService;
    private List<Category> categoryList;




    // Metodo GET
    public List<CategoryDto> findAll() throws Exception {
        this.categoryList = this.categoryService.findAll();
        List<CategoryDto> categoryDtoList = new ArrayList<>();
        this.categoryList.stream().forEach(category -> {
            CategoryDto categoryDto = new CategoryDto();
            categoryDto.setId(category.getId());
            categoryDto.setNombreCategoria(category.getNombreCategoria());


            categoryDtoList.add(categoryDto);
        });
        return categoryDtoList;
    }

    // Metodo POST
    public void createCategory(CategoryDto categoryDto) throws Exception {
        Category category = new Category();
        category.setNombreCategoria(categoryDto.getNombreCategoria());

        this.categoryService.create(category);
        int categoryId = category.getId();
        categoryDto.setId(categoryId);
    }



    // Metodo PUT
    public void updatedCategory(int id, CategoryDto updatedCategoryDto) throws Exception {
        Category existingCategory = categoryService.findById(id);

        if (existingCategory == null) {
            throw new Exception("Category not found with id: " + id);
        }
        existingCategory.setId(id);
        existingCategory.setNombreCategoria(updatedCategoryDto.getNombreCategoria());

        this.categoryService.update(existingCategory);
    }


    // Método DELETE (Eliminación lógica)
    public void deleteCategory(int id) throws Exception {
        Category existingCategory = categoryService.findById(id);
        if (existingCategory == null) {
            throw new Exception("Category not found with id: " + id);
        }
        existingCategory.setEliminado(true);
        categoryService.update(existingCategory);
    }
}

