package com.cusmetichi.demo.business;

import java.util.ArrayList;
import java.util.List;

import com.cusmetichi.demo.dtos.*;
import com.cusmetichi.demo.entity.*;
import com.cusmetichi.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cusmetichi.demo.service.CustomerService;
import com.cusmetichi.demo.service.ProductService;

@Component
public class CustomerBusiness {
    @Autowired
    private CustomerService customerService;
    @Autowired
    private UserService userService;
    private List<Customer> customerList;
    private List<CustomerDto> customerDtoList = new ArrayList<>();


    // Metodo GET
    public List<CustomerDto> findAll() throws Exception {
        this.customerList = this.customerService.findAll();
         List<CustomerDto> customerDtoList = new ArrayList<>();
        this.customerList.stream().forEach(customer -> {
            CustomerDto customerDto = new CustomerDto();
            customerDto.setId(customer.getId());
            customerDto.setNombreCliente(customer.getNombreCliente());
            customerDto.setApellidoCliente(customer.getApellidoCliente());
            customerDto.setIdentificacionClientes(customer.getIdentificacionClientes());
            customerDto.setEmailCliente(customer.getEmailCliente());
            customerDto.setTelCliente(customer.getTelCliente());
            customerDto.setDireccionCliente(customer.getDireccionCliente());

            User user=customer.getFkid_user();
            if (user != null){
                UserDto userDto=new UserDto();
                userDto.setId(user.getId());
                userDto.setNombre(user.getNombre());
                userDto.setEmail(user.getEmail());
                userDto.setContraseña(user.getContraseña());
                customerDto.setFkid_user(userDto);

                //Llave foranea de Rol

                Role role=customer.getFkid_user().getFkid_rol();
                RoleDto roleDto=new RoleDto();
                roleDto.setId(role.getId());
                roleDto.setNombre(role.getNombre());
                userDto.setFkid_rol(roleDto);
            }

            this.customerDtoList.add(customerDto);

        });
        return customerDtoList;
    }


    // Metodo POST para crear un cliente
    public void createCustomer(CustomerDto customerDto) throws Exception {
        Customer customer = new Customer();

        // Llave foranea - Usuario
        UserDto userDto = customerDto.getFkid_user();
        User user = userService.findById(userDto.getId());

        if (user == null) {
            throw new Exception("User not found with id: " + userDto.getId());
        }
        customer.setFkid_user(user);



        // Establecer los datos del cliente
        customer.setNombreCliente(customerDto.getNombreCliente());
        customer.setApellidoCliente(customerDto.getApellidoCliente());
        customer.setIdentificacionClientes(customerDto.getIdentificacionClientes());
        customer.setEmailCliente(customerDto.getEmailCliente());
        customer.setTelCliente(customerDto.getTelCliente());
        customer.setDireccionCliente(customerDto.getDireccionCliente());

        // Crear el cliente en la base de datos a través del servicio correspondiente
        this.customerService.create(customer);

        // Establecer el ID del cliente generado y actualizar el DTO
        int customerId = customer.getId();
        customerDto.setId(customerId);
    }



    // Metodo PUT
    public void updatedCustomer(int id, CustomerDto updatedCustomerDto) throws Exception {
        Customer existingCustomer = customerService.findById(id);
        if (existingCustomer == null) {
            throw new Exception("cliente no encontrado");
        }

        existingCustomer.setNombreCliente(updatedCustomerDto.getNombreCliente());
        existingCustomer.setApellidoCliente(updatedCustomerDto.getApellidoCliente());
        existingCustomer.setEmailCliente(updatedCustomerDto.getEmailCliente());
        existingCustomer.setTelCliente(updatedCustomerDto.getTelCliente());
        existingCustomer.setDireccionCliente(updatedCustomerDto.getDireccionCliente());
        existingCustomer.setIdentificacionClientes(updatedCustomerDto.getIdentificacionClientes());


        // Manejar la llave foránea - Producto
        if (updatedCustomerDto.getFkid_user() != null) {
            int userId = updatedCustomerDto.getFkid_user().getId();
            User user = userService.findById(userId);
            if (user == null) {
                throw new Exception("id usuario" + userId + " no se encuentra");
            }
            existingCustomer.setFkid_user(user);
        }

        this.customerService.update(existingCustomer);

    }

    // Metodo DELETE
    public void deleteCustomer(int id) throws Exception {
        Customer existingCustomer = customerService.findById(id);
        if (existingCustomer == null) {
            throw new Exception("Customer not found with id: " + id);
        }
        existingCustomer.setEliminado(true);
        customerService.update(existingCustomer);
    }

    public CustomerDto findCustomerById(int id) {
        return null;
    }

}





