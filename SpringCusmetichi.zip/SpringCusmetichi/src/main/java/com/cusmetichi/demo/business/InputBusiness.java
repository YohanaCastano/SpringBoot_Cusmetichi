package com.cusmetichi.demo.business;
import java.util.ArrayList;
import java.util.List;

import com.cusmetichi.demo.entity.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cusmetichi.demo.dtos.InputDto;
import com.cusmetichi.demo.entity.Input;
import com.cusmetichi.demo.service.InputService;

@Component
public class InputBusiness {
    @Autowired
    private InputService inputService;
    private List<Input> inputList;


    // Metodo GET
    public List<InputDto> findAll() throws Exception {
        this.inputList = this.inputService.findAll();
        List<InputDto> inputDtoList = new ArrayList<>();
        this.inputList.stream().forEach(input -> {
            InputDto inputDto = new InputDto();
            inputDto.setId(input.getId());
            inputDto.setCantidadEntrada(input.getCantidadEntrada());
            inputDto.setFechaEntrada(input.getFechaEntrada());

            inputDtoList.add(inputDto);
        });
        return inputDtoList;
    }


    // Metodo POST
    public void createInput(InputDto inputDto) throws Exception {
        Input input = new Input();
        input.setCantidadEntrada(inputDto.getCantidadEntrada());
        input.setFechaEntrada(inputDto.getFechaEntrada());

        this.inputService.create(input);

        int inputId = input.getId();
        inputDto.setId(inputId);

    }

    // Metodo PUT
    public void updatedInput(int id, InputDto updatedInputDto) throws Exception {
        Input existingInput = inputService.findById(id);
        if (existingInput == null) {
            throw new Exception("Brand not found with id: " + id);
        }
        existingInput.setCantidadEntrada(updatedInputDto.getCantidadEntrada());
        existingInput.setFechaEntrada(updatedInputDto.getFechaEntrada());

        this.inputService.update(existingInput);

    }

    // Método DELETE
    public void deleteInput(int id) throws Exception {
        Input existingInput = inputService.findById(id);
        if (existingInput == null) {
            throw new Exception("Input not found with id: " + id);
        }
        existingInput.setEliminado(true);
        inputService.update(existingInput);
    }
}



