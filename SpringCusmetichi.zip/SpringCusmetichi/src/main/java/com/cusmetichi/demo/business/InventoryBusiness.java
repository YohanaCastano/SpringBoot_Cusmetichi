package com.cusmetichi.demo.business;

import java.util.ArrayList;
import java.util.List;

import com.cusmetichi.demo.dtos.ProductDto;
import com.cusmetichi.demo.entity.Product;
import com.cusmetichi.demo.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cusmetichi.demo.dtos.InputDto;
import com.cusmetichi.demo.dtos.InventoryDto;
import com.cusmetichi.demo.dtos.OutputDto;
import com.cusmetichi.demo.entity.Input;
import com.cusmetichi.demo.entity.Inventory;
import com.cusmetichi.demo.entity.Output;
import com.cusmetichi.demo.service.InputService;
import com.cusmetichi.demo.service.InventoryService;
import com.cusmetichi.demo.service.OutPutService;

@Component
public class InventoryBusiness {
    @Autowired
    private InventoryService inventoryService;
    @Autowired
    private InputService inputService;
    @Autowired
    private OutPutService outPutService;

    @Autowired
    private ProductService productService;

    private List<Inventory> inventoryList;



    // Metodo GET
    public List<InventoryDto> findAll() throws Exception {
        this.inventoryList = this.inventoryService.findAll();
         List<InventoryDto> inventoryDtoList = new ArrayList<>();
        this.inventoryList.stream().forEach(inventory -> {
            InventoryDto inventoryDto = new InventoryDto();
            inventoryDto.setId(inventory.getId());
            inventoryDto.setCantidadProducto(inventory.getCantidadProducto());


            // Llave Foranea - Input - Entrada
            Input input = inventory.getFkidInput();
            if (input != null) {
                InputDto inputDto = new InputDto();
                inputDto.setId(input.getId());
                inputDto.setCantidadEntrada(input.getCantidadEntrada());
                inputDto.setFechaEntrada(input.getFechaEntrada());
                inventoryDto.setFkidInput(inputDto);
            }

            // Llave Foranea - Output - Salida
            Output output = inventory.getFkidOutput();
            if (output != null) {
                OutputDto outputDto = new OutputDto();
                outputDto.setId(output.getId());
                outputDto.setCantidadSalidas(output.getCantidadSalidas());
                outputDto.setFechaSalida(output.getFechaSalida());
                outputDto.setTipoSalida(output.getTipoSalida());
                outputDto.setIvaTotal(output.getIvaTotal());
                outputDto.setMetodoPago(output.getMetodoPago());
                inventoryDto.setFkidOutput(outputDto);
            }

                    // Llave Foranea - Producto - Salida
            Product product = inventory.getFkid_product();
            if (product != null) {
                ProductDto productDto = new ProductDto();
                productDto.setId((product.getId()));
                productDto.setNombreProducto(product.getNombreProducto());
                productDto.setDescripcionProducto(product.getDescripcionProducto());
                productDto.setCantidadProducto(product.getCantidadProducto());
                productDto.setTamañoProducto(product.getTamañoProducto());
                productDto.setIvaProducto(product.getIvaProducto());
                productDto.setImagen(product.getImagen());
            }
        });
        return inventoryDtoList;
    }


    // Metodo POST
    public void createInventory(InventoryDto inventoryDto) throws Exception {
        Inventory inventory = new Inventory();
        inventory.setCantidadProducto(inventoryDto.getCantidadProducto());


        //Llave Foranea - Product - Productos
        ProductDto productDto = inventoryDto.getFkid_Product();
        Product product = productService.findById(productDto.getId());
        if (product == null) {
            throw new Exception("Product not found with id: "+ productDto.getId());
        }
        inventory.setFkid_product(product);


        // Llave Foranea - Input - Entrada
        InputDto inputDto = inventoryDto.getFkidInput();
        Input input = inputService.findById(inputDto.getId());
        if (input == null) {
            throw new Exception("Input not found with id: "+ inputDto.getId());
        }
        inventory.setFkidInput(input);

        // Llave Foranea - Output - Salida
        OutputDto outputDto = inventoryDto.getFkidOutput();
        Output output = outPutService.findById(inventoryDto.getId());
        if (output == null) {
            throw new Exception("Output not found with id: "+ outputDto.getId());
        }
        inventory.setFkidOutput(output);

        this.inventoryService.create(inventory);

    }

    // Metodo PUT
    public void updatedInventory(int id, InventoryDto updatedInventoryDto) throws Exception {
        Inventory existingInventory = inventoryService.findById(id);
        if (existingInventory == null) {
            throw new Exception("Inventory not found with id: " + id);
        }
        existingInventory.setCantidadProducto(updatedInventoryDto.getCantidadProducto());


        // Llave Foranea - Input - Entrada
        if(updatedInventoryDto.getFkidInput() != null){

            int inputId = updatedInventoryDto.getFkidInput().getId();
            Input input = inputService.findById(inputId);
            if(input == null) {
                throw new Exception(inputId + " Not found");
            }
            existingInventory.setFkidInput(input);
        }

        this.inventoryService.update(existingInventory);


        //llave foranea producto
        if (updatedInventoryDto.getFkid_Product() !=null){

            int productId = updatedInventoryDto.getFkid_Product().getId();
            Product product = productService.findById(productId);
            if(product ==null) {
                throw new Exception(productId + "not found");
            }
            existingInventory.setFkid_product(product);
        }

        // Llave Foranea - Output - Salida
        if(updatedInventoryDto.getFkidOutput() != null){

            int outputId = updatedInventoryDto.getFkidOutput().getId();
            Output output = outPutService.findById(outputId);
            if(output == null) {
                throw new Exception(outputId + " Not found");
            }
            existingInventory.setFkidOutput(output);
        }
        this.inventoryService.update(existingInventory);
    }
}
