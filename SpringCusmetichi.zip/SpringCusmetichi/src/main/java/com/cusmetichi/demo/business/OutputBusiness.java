package com.cusmetichi.demo.business;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cusmetichi.demo.dtos.OutputDto;
import com.cusmetichi.demo.entity.Output;
import com.cusmetichi.demo.service.OutPutService;

@Component
public class OutputBusiness {
    @Autowired
    private OutPutService outPutService;

    private List<Output> outputList;

    // Metodo GET
    public List<OutputDto> findAll() throws Exception {
        this.outputList = this.outPutService.findAll();
        List<OutputDto> outputDtoList = new ArrayList<>();
        this.outputList.stream().forEach(output -> {
            OutputDto outputDto = new OutputDto();
            outputDto.setId(output.getId());
            outputDto.setCantidadSalidas(output.getCantidadSalidas());
            outputDto.setTipoSalida(output.getTipoSalida());
            outputDto.setFechaSalida(output.getFechaSalida());
            outputDto.setIvaTotal(output.getIvaTotal());
            outputDto.setMetodoPago(output.getMetodoPago());



            outputDtoList.add(outputDto);
        });
        return outputDtoList;
    }


    // Metodo POST
    public void createOutput(OutputDto outputDto) throws Exception {
        Output output = new Output();
        output.setCantidadSalidas(outputDto.getCantidadSalidas());
        output.setTipoSalida(outputDto.getTipoSalida());
        output.setFechaSalida(outputDto.getFechaSalida());
        output.setIvaTotal(outputDto.getIvaTotal());
        output.setMetodoPago(outputDto.getMetodoPago());

        this.outPutService.create(output);
    }


    // Metodo PUT
    public void updatedOutput(int id, OutputDto updatedOutputDto) throws Exception {
        Output existingOutput = outPutService.findById(id);
        if (existingOutput == null) {
            throw new Exception("Output not found with id: " + id);
        }
        existingOutput.setCantidadSalidas(updatedOutputDto.getCantidadSalidas());
        existingOutput.setFechaSalida(updatedOutputDto.getFechaSalida());
        existingOutput.setTipoSalida(updatedOutputDto.getTipoSalida());
        existingOutput.setIvaTotal(updatedOutputDto.getIvaTotal());
        existingOutput.setMetodoPago(updatedOutputDto.getMetodoPago());

            this.outPutService.update(existingOutput);
    }
    // Metodo DELETE
    public void deleteOutput(int id) throws Exception {
        Output existingOutput = outPutService.findById(id);
        if (existingOutput == null) {
            throw new Exception("Output not found with id: " + id);
        }
        existingOutput.setEliminado(true);
        outPutService.update(existingOutput);
    }
    }
