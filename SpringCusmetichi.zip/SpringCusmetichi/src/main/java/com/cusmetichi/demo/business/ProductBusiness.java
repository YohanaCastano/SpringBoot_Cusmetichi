package com.cusmetichi.demo.business;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import com.cusmetichi.demo.dtos.*;
import com.cusmetichi.demo.entity.*;
import com.cusmetichi.demo.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static org.springframework.data.jpa.domain.AbstractPersistable_.id;

@Component
public class ProductBusiness {

    @Autowired
    private ProductService productService;
    @Autowired
    private SupplierService supplierService;
   @Autowired
   private CategoryService categoryService;

   @Autowired
   private BrandService brandService;

    private List<Product> productList;


    // Metodo GET
    public List<ProductDto> findAll() throws Exception {
        this.productList = this.productService.findAll();
        List<ProductDto> productDtoList = new ArrayList<>();
        this.productList.stream().forEach(product -> {
            ProductDto productDto = new ProductDto();
            productDto.setId(product.getId());
            productDto.setNombreProducto(product.getNombreProducto());
            productDto.setTamañoProducto(product.getTamañoProducto());
            productDto.setDescripcionProducto(product.getDescripcionProducto());
            productDto.setPrecioProducto(product.getPrecioProducto());
            productDto.setIvaProducto(product.getIvaProducto());
            productDto.setCantidadProducto(product.getCantidadProducto());
            productDto.setImagen(product.getImagen());



            // Llave Foranea  - Proveedor - Supplier
            Supplier supplier = product.getFkidProveedor();
            if (supplier != null) {
                SupplierDto supplierDto = new SupplierDto();
                supplierDto.setId(supplier.getId());
                supplierDto.setApellidoProveedor(supplier.getApellidoProveedor());
                supplierDto.setEmailProveedor(supplier.getEmailProveedor());
                supplierDto.setEmpresaProveedor(supplier.getEmpresaProveedor());
                supplierDto.setIdentificacionProveedor(supplier.getIdentificacionProveedor());
                supplierDto.setNombreProveedor(supplier.getNombreProveedor());
                supplierDto.setTelefonoProveedor(supplier.getTelefonoProveedor());

                productDto.setFkidProveedor(supplierDto);

            }
            //llave forane categoria
            Category category =product.getFkid_category();
            if (category != null){

                CategoryDto categoryDto = new CategoryDto();
                categoryDto.setId(category.getId());
                categoryDto.setNombreCategoria(category.getNombreCategoria());
                productDto.setFkid_category(categoryDto);
            }

            //llave foranea marca
            Brand brand =product.getFkid_brand();
            if (brand != null){

                BrandDto brandDto = new BrandDto();
                brandDto.setId(brand.getId());
                brandDto.setNombreMarca(brand.getNombreMarca());
                productDto.setFkid_brand(brandDto);
            }


            productDtoList.add(productDto);
        });
        return productDtoList;
    }


    // Metodo POST
    public void createProduct(ProductDto productDto) throws Exception {
        Product product = new Product();

        // llave foranea categoria
        CategoryDto categoryDto = productDto.getFkid_category();
        Category category = categoryService.findById(categoryDto.getId());
        if (category == null) {
            throw new Exception("Supplier not found with id: " + categoryDto.getId());
        }
        product.setFkid_category(category);

        // Llave Foranea  - Supplier - Proveedor
        SupplierDto supplierDto = productDto.getFkidProveedor();
        Supplier supplier = supplierService.findById(supplierDto.getId());
        if (supplier == null) {
            throw new Exception("Supplier not found with id: " + supplierDto.getId());
        }
        product.setFkidProveedor(supplier);

        //llave foranea marca

        BrandDto brandDto = productDto.getFkid_brand();
        Brand brand = brandService.findById(brandDto.getId());
        if (brand == null) {
            throw new Exception("Brand not found with id: " + brandDto.getId());
        }
        product.setFkid_brand(brand);

        product.setNombreProducto(productDto.getNombreProducto());
        product.setTamañoProducto(productDto.getTamañoProducto());
        product.setDescripcionProducto(productDto.getDescripcionProducto());
        product.setPrecioProducto(productDto.getPrecioProducto());
        product.setIvaProducto(productDto.getIvaProducto());
        product.setCantidadProducto(productDto.getCantidadProducto());
        product.setImagen(productDto.getImagen());


        this.productService.create(product);

        int productId = product.getId();
        productDto.setId(productId);
    }


    // Metodo PUT
    public void updatedProduct(int id, ProductDto updatedProductDto) throws Exception {
        Product existingProduct = productService.findById(id);
        if (existingProduct == null) {
            throw new Exception("Product not found with id: " + id);
        }
        existingProduct.setDescripcionProducto(updatedProductDto.getDescripcionProducto());
        existingProduct.setIvaProducto(updatedProductDto.getIvaProducto());
        existingProduct.setNombreProducto(updatedProductDto.getNombreProducto());
        existingProduct.setPrecioProducto(updatedProductDto.getPrecioProducto());
        existingProduct.setTamañoProducto(updatedProductDto.getTamañoProducto());
        existingProduct.setCantidadProducto(updatedProductDto.getCantidadProducto());


        // Llave Foranea  - Supplier - Proveedor
        if(updatedProductDto.getFkidProveedor() != null){
            int supplierId = updatedProductDto.getFkidProveedor().getId();
            Supplier supplier = supplierService.findById(supplierId);
            if(supplier == null) {
                throw new Exception(supplierId + "Not found");
            }
            existingProduct.setFkidProveedor(supplier);
        }
        this.productService.update(existingProduct);

        // llave foranea de categoria
        if(updatedProductDto.getFkid_category() != null){
            int categoryId = updatedProductDto.getFkid_category().getId();
            Category category = categoryService.findById(categoryId);
            if(category == null) {
                throw new Exception(categoryId + "Not found");
            }
            existingProduct.setFkid_category(category);
        }
        this.productService.update(existingProduct);

        //llave foranea de marca

        if(updatedProductDto.getFkid_brand() != null){
            int brandId = updatedProductDto.getFkid_brand().getId();
            Brand brand = brandService.findById(brandId);
            if(brand == null) {
                throw new Exception(brandId + "Not found");
            }
            existingProduct.setFkid_brand(brand);
        }
        this.productService.update(existingProduct);
    }


    // Metodo DELETE
    public void deleteProduct(int id) throws Exception {
        Product existingProdduct = productService.findById(id);
        if (existingProdduct == null) {
            throw new Exception("Customer not found with id: " + id);
        }
        existingProdduct.setEliminado(true);
        productService.update(existingProdduct);
    }
}





