package com.cusmetichi.demo.business;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cusmetichi.demo.dtos.PurchaseSupplierDto;
import com.cusmetichi.demo.dtos.SupplierDto;
import com.cusmetichi.demo.entity.PurchaseSupplier;
import com.cusmetichi.demo.entity.Supplier;
import com.cusmetichi.demo.service.PurchaseSupplierService;
import com.cusmetichi.demo.service.SupplierService;

@Component
public class PurchaseSupplierBusiness {
    @Autowired
    private PurchaseSupplierService purchaseSupplierService;
    @Autowired
    private SupplierService supplierService;
    private List<PurchaseSupplier> purchaseSupplierList;


    // Metodo GET
    public List<PurchaseSupplierDto> findAll() throws Exception {
        this.purchaseSupplierList = this.purchaseSupplierService.findAll();
        List<PurchaseSupplierDto> purchaseSupplierDtoList = new ArrayList<>();
        this.purchaseSupplierList.stream().forEach(purchaseSupplier -> {
            PurchaseSupplierDto purchaseSupplierDto = new PurchaseSupplierDto();
            purchaseSupplierDto.setId(purchaseSupplier.getId());
            purchaseSupplierDto.setCantidadProducto(purchaseSupplier.getCantidadProducto());
            purchaseSupplierDto.setEstadoPedido(purchaseSupplier.getEstadoPedido());
            purchaseSupplierDto.setFechaPedido(purchaseSupplier.getFechaPedido());
            purchaseSupplierDto.setCostoProducto(purchaseSupplier.getCostoProducto());


            // Llave Foranea - Proveedor
            Supplier supplier = purchaseSupplier.getFkidProveedor();
            if (supplier != null) {
                SupplierDto supplierDto = new SupplierDto();
                supplierDto.setId(supplier.getId());
                supplierDto.setApellidoProveedor(supplier.getApellidoProveedor());
                supplierDto.setEmailProveedor(supplier.getEmailProveedor());
                supplierDto.setEmpresaProveedor(supplier.getEmpresaProveedor());
                supplierDto.setIdentificacionProveedor(supplier.getIdentificacionProveedor());
                supplierDto.setNombreProveedor(supplier.getNombreProveedor());
                supplierDto.setTelefonoProveedor(supplier.getTelefonoProveedor());

                purchaseSupplierDto.setFkidProveedor(supplierDto);

            }

            purchaseSupplierDtoList.add(purchaseSupplierDto);
        });
        return purchaseSupplierDtoList;
    }


    // Metodo POST
    public void createPurchaseSupplier(PurchaseSupplierDto purchaseSupplierDto) throws Exception {
        PurchaseSupplier purchaseSupplier = new PurchaseSupplier();
        purchaseSupplier.setCantidadProducto(purchaseSupplierDto.getCantidadProducto());
        purchaseSupplier.setEstadoPedido(purchaseSupplierDto.getEstadoPedido());
        purchaseSupplier.setFechaPedido(purchaseSupplierDto.getFechaPedido());
        purchaseSupplier.setCostoProducto(purchaseSupplierDto.getCostoProducto());


        // Llave Foranea - Supplier - Proveedor
        SupplierDto supplierDto = purchaseSupplierDto.getFkidProveedor();
        Supplier supplier = supplierService.findById(supplierDto.getId());
        if (supplier == null) {
            throw new Exception("Supplier not found with id: ");
        }
        purchaseSupplier.setFkidProveedor(supplier);

        this.purchaseSupplierService.create(purchaseSupplier);

    }


    // Metodo PUT
    public void updatedPurchaseSupplier(int id, PurchaseSupplierDto updatedPurchaseSupplierDto) throws Exception {
        PurchaseSupplier existingPurchaseSupplier = purchaseSupplierService.findById(id);
        if (existingPurchaseSupplier == null) {
            throw new Exception("Brand not found with id: " + id);
        }
        existingPurchaseSupplier.setCantidadProducto(updatedPurchaseSupplierDto.getCantidadProducto());
        existingPurchaseSupplier.setCostoProducto(updatedPurchaseSupplierDto.getCostoProducto());
        existingPurchaseSupplier.setEstadoPedido(updatedPurchaseSupplierDto.getEstadoPedido());
        existingPurchaseSupplier.setFechaPedido(updatedPurchaseSupplierDto.getFechaPedido());


        // Llave Foranea - Supplier - Proveedor
        if (updatedPurchaseSupplierDto.getFkidProveedor() != null) {
            int supplierId = updatedPurchaseSupplierDto.getFkidProveedor().getId();
            Supplier supplier = supplierService.findById(supplierId);
            if(supplier == null) {
                throw new Exception(supplierId + "Not found");
            }
            existingPurchaseSupplier.setFkidProveedor(supplier);
        }

        this.purchaseSupplierService.update(existingPurchaseSupplier);
    }


    // Metodo DELETE de la lista pero no de la base de datos
    public void deletePurchaseSupplierFromList(int id) throws Exception {
        PurchaseSupplier purchaseSupplier = purchaseSupplierList.stream()
                .filter(ps -> ps.getId() == id)
                .findFirst()
                .orElseThrow(() -> new Exception("Purchase Supplier not found with id: " + id));

        purchaseSupplierList.remove(purchaseSupplier);
    }
}