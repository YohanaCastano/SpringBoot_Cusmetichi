package com.cusmetichi.demo.business;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cusmetichi.demo.dtos.RoleDto;
import com.cusmetichi.demo.entity.Role;
import com.cusmetichi.demo.service.RoleService;

@Component
public class RoleBusiness {
    @Autowired
    private RoleService roleService;
    private List<Role> roleList;



    // Metodo GET
    public List<RoleDto> findAll() throws Exception {
        this.roleList = this.roleService.findAll();
         List<RoleDto> roleDtoList = new ArrayList<>();
        this.roleList.stream().forEach(role -> {
            RoleDto roleDto = new RoleDto();
            roleDto.setId(role.getId());
            roleDto.setNombre(role.getNombre());
            roleDtoList.add(roleDto);
        });
        return roleDtoList;
    }

    public void createRole(RoleDto roleDto) throws Exception {
        if (roleDto == null) {
            throw new Exception("El objeto RoleDto es nulo");
        }

        Role role = new Role();
        role.setNombre(roleDto.getNombre());

        this.roleService.create(role);
        roleDto.setId(role.getId()); // Use the role object directly
    }

    // Metodo PUT
    public RoleDto updatedRole(int id, RoleDto updatedRoleDto) throws Exception {
        Role existingRole = roleService.findById(id);
        if (existingRole == null) {
            throw new Exception("Brand not found with id: " + id);
        }
        existingRole.setId(id);
        existingRole.setNombre(updatedRoleDto.getNombre());
        roleService.update(existingRole);

        return updatedRoleDto;
    }



}
