package com.cusmetichi.demo.business;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cusmetichi.demo.dtos.SaleDto;
import com.cusmetichi.demo.entity.Sale;
import com.cusmetichi.demo.service.SaleService;

@Component
public class SaleBusiness {
    @Autowired
    private SaleService saleService;

    private List<Sale> saleList;


    // Metodo GET
    public List<SaleDto> findAll() throws Exception {
        this.saleList = this.saleService.findAll();
        List<SaleDto> saleDtoList = new ArrayList<>();
        this.saleList.stream().forEach(sale -> {
            SaleDto saleDto = new SaleDto();
            saleDto.setId(sale.getId());
            saleDto.setIvaTotal(sale.getIvaTotal());
            saleDto.setFecha(sale.getFecha());
            saleDto.setCantidad(sale.getCantidad());
            saleDto.setTotal(sale.getTotal());

            saleDtoList.add(saleDto);
            });
            return saleDtoList;
        }


    // Metodo POST
    public void createSale(SaleDto saleDto) throws Exception {
        Sale sale = new Sale();
        sale.setIvaTotal(saleDto.getIvaTotal());
        sale.setFecha(saleDto.getFecha());
        sale.setCantidad(saleDto.getCantidad());
        sale.setTotal(saleDto.getTotal());

        this.saleService.create(sale);
        int saleId = sale.getId();
        saleDto.setId(saleId);
    }

    // Metodo PUT
    public void updatedSale(int id, SaleDto updatedSaleDto) throws Exception {
        Sale existingSale = saleService.findById(id);
        if (existingSale == null) {
            throw new Exception("Sale not found with id: " + id);
        }
        existingSale.setIvaTotal(updatedSaleDto.getIvaTotal());
        existingSale.setFecha(updatedSaleDto.getFecha());
        existingSale.setCantidad(updatedSaleDto.getCantidad());
        existingSale.setTotal(updatedSaleDto.getTotal());

        this.saleService.update(existingSale);
    }
}