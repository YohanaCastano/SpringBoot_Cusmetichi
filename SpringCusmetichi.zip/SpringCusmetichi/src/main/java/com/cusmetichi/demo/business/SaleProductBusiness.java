package com.cusmetichi.demo.business;

import com.cusmetichi.demo.dtos.*;
import com.cusmetichi.demo.entity.*;
import com.cusmetichi.demo.service.ProductService;
import com.cusmetichi.demo.service.SaleProductService;
import com.cusmetichi.demo.service.SaleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class SaleProductBusiness {
    @Autowired
    private SaleProductService saleProductService;

    @Autowired
    private ProductService productService;

    @Autowired
    private SaleService saleService;

    private List<SaleProduct> saleProductList;

    //Metodo GET
    public List<SaleProductDto> findAll() throws Exception {
        this.saleProductList = this.saleProductService.findAll();
        List<SaleProductDto> saleProductDtoList = new ArrayList<>();
        this.saleProductList.stream().forEach(saleProduct -> {
            SaleProductDto saleProductDto = new SaleProductDto();
            saleProductDto.setCantidad(saleProduct.getCantidad());

            Sale sale = saleProduct.getFkid_sale();
            if (sale != null) {
                SaleDto saleDto = new SaleDto();
                saleDto.setId(sale.getId());
                saleDto.setIvaTotal(sale.getIvaTotal());
                saleDto.setFecha(sale.getFecha());
                saleDto.setCantidad(sale.getCantidad());
                saleDto.setTotal(sale.getTotal());
                saleProductDto.setFkid_sale(saleDto);
            }


            Product product = saleProduct.getFkid_product();
            if (product != null) {
                ProductDto productDto = new ProductDto();
                productDto.setId(product.getId());
                productDto.setNombreProducto(product.getNombreProducto());
                productDto.setTamañoProducto(product.getTamañoProducto());
                productDto.setDescripcionProducto(product.getDescripcionProducto());
                productDto.setPrecioProducto(product.getPrecioProducto());
                productDto.setIvaProducto(product.getIvaProducto());
                productDto.setCantidadProducto(product.getCantidadProducto());
                productDto.setImagen(product.getImagen());

                Supplier supplier = product.getFkidProveedor();
                if (supplier != null) {
                    SupplierDto supplierDto = new SupplierDto();
                    supplierDto.setId(supplier.getId());
                    supplierDto.setApellidoProveedor(supplier.getApellidoProveedor());
                    supplierDto.setEmailProveedor(supplier.getEmailProveedor());
                    supplierDto.setEmpresaProveedor(supplier.getEmpresaProveedor());
                    supplierDto.setIdentificacionProveedor(supplier.getIdentificacionProveedor());
                    supplierDto.setNombreProveedor(supplier.getNombreProveedor());
                    supplierDto.setTelefonoProveedor(supplier.getTelefonoProveedor());
                    productDto.setFkidProveedor(supplierDto);
                }

                //llave forane categoria
                Category category = product.getFkid_category();
                if (category != null) {

                    CategoryDto categoryDto = new CategoryDto();
                    categoryDto.setId(category.getId());
                    categoryDto.setNombreCategoria(category.getNombreCategoria());
                    productDto.setFkid_category(categoryDto);
                }

                //llave foranea marca
                Brand brand = product.getFkid_brand();
                if (brand != null) {

                    BrandDto brandDto = new BrandDto();
                    brandDto.setId(brand.getId());
                    brandDto.setNombreMarca(brand.getNombreMarca());
                    productDto.setFkid_brand(brandDto);
                }
                saleProductDto.setFkid_product(productDto);
            }
            saleProductDtoList.add(saleProductDto);
        });
        return saleProductDtoList;
    }

    //Metodo POST

    public void createSaleProduct(SaleProductDto saleProductDto) throws Exception {
        SaleProduct saleProduct = new SaleProduct();

        //Llave foranea - Product - Producto
        ProductDto productDto = saleProductDto.getFkid_product();
        Product product = productService.findById(productDto.getId());
        if (product == null) {
            throw new Exception("Product not found with id: " + productDto.getId());
        }
        saleProduct.setFkid_product(product);

        //Llave foranea - Sale - Venta
        SaleDto saleDto = saleProductDto.getFkid_sale();
        Sale sale = saleService.findById(saleDto.getId());
        if (sale == null) {
            throw new Exception("Sale not found with id: " + saleDto.getId());
        }

        saleProduct.setCantidad(saleProductDto.getCantidad());

        this.saleProductService.create(saleProduct);

        int saleProductId = saleProduct.getId();
        saleProductDto.setId(saleProductId);
    }


    //Metodo Put
    public void updatedSaleProduct(int id, SaleProductDto updatedSaleProductDto) throws Exception {
        SaleProduct existingSaleProduct = saleProductService.findById(id);
        if (existingSaleProduct == null) {
            throw new Exception(("producto no encontrado con el id" + id));
        }
        existingSaleProduct.setCantidad(updatedSaleProductDto.getCantidad());

        //llave foranea productos
        if (updatedSaleProductDto.getFkid_product() != null) {
            int productId = updatedSaleProductDto.getFkid_product().getId();
            Product product = productService.findById(productId);
            if (product== null) {
                throw new Exception(productId + "not found");
            }
            existingSaleProduct.setFkid_product(product);
        }
        this.saleProductService.update(existingSaleProduct);
    }
    //llave foranea salidas

}









