package com.cusmetichi.demo.business;

import java.util.ArrayList;
import java.util.List;

import com.cusmetichi.demo.dtos.SupplierDto;
import com.cusmetichi.demo.entity.Supplier;
import com.cusmetichi.demo.service.SupplierService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SupplierBusiness {

    @Autowired
    private SupplierService supplierService;
    private List<Supplier> supplierList;
    private List<SupplierDto> supplierDtoList = new ArrayList<>();

    // Metodo GET
    public List<SupplierDto> findAll() throws Exception {
        this.supplierList = this.supplierService.findAll();
        this.supplierDtoList.clear();
        this.supplierList.forEach(supplier -> {
            SupplierDto supplierDto = new SupplierDto();
            supplierDto.setId(supplier.getId());
            supplierDto.setNombreProveedor(supplier.getNombreProveedor());
            supplierDto.setApellidoProveedor(supplier.getApellidoProveedor());
            supplierDto.setIdentificacionProveedor(supplier.getIdentificacionProveedor());
            supplierDto.setEmailProveedor(supplier.getEmailProveedor());
            supplierDto.setTelefonoProveedor(supplier.getTelefonoProveedor());
            supplierDto.setEmpresaProveedor(supplier.getEmpresaProveedor());
            this.supplierDtoList.add(supplierDto);
        });
        return this.supplierDtoList;
    }

    // Metodo POST
    public void createSupplier(SupplierDto supplierDto) throws Exception {
        Supplier supplier = new Supplier();
        supplier.setNombreProveedor(supplierDto.getNombreProveedor());
        supplier.setApellidoProveedor(supplierDto.getApellidoProveedor());
        supplier.setIdentificacionProveedor(supplierDto.getIdentificacionProveedor());
        supplier.setEmailProveedor(supplierDto.getEmailProveedor());
        supplier.setTelefonoProveedor(supplierDto.getTelefonoProveedor());
        supplier.setEmpresaProveedor(supplierDto.getEmpresaProveedor());

        this.supplierService.create(supplier);
    }

    // Metodo PUT
    public SupplierDto updatedSupplier(int id, SupplierDto updatedSupplierDto) throws Exception {
        Supplier existingSupplier = supplierService.findById(id);
        if (existingSupplier == null) {
            throw new Exception("Supplier not found with id: " + id);
        }
        existingSupplier.setApellidoProveedor(updatedSupplierDto.getApellidoProveedor());
        existingSupplier.setEmailProveedor(updatedSupplierDto.getEmailProveedor());
        existingSupplier.setIdentificacionProveedor(updatedSupplierDto.getIdentificacionProveedor());
        existingSupplier.setNombreProveedor(updatedSupplierDto.getNombreProveedor());
        existingSupplier.setTelefonoProveedor(updatedSupplierDto.getTelefonoProveedor());

        supplierService.update(existingSupplier);

        // Devolver los datos actualizados
        SupplierDto updatedDto = new SupplierDto();
        updatedDto.setId(existingSupplier.getId());
        updatedDto.setNombreProveedor(existingSupplier.getNombreProveedor());
        updatedDto.setApellidoProveedor(existingSupplier.getApellidoProveedor());
        updatedDto.setIdentificacionProveedor(existingSupplier.getIdentificacionProveedor());
        updatedDto.setEmailProveedor(existingSupplier.getEmailProveedor());
        updatedDto.setTelefonoProveedor(existingSupplier.getTelefonoProveedor());
        updatedDto.setEmpresaProveedor(existingSupplier.getEmpresaProveedor());

        return updatedDto;
    }

    // Metodo DELETE
    public void deleteSupplier(int id) throws Exception {
        Supplier existingSupplier = supplierService.findById(id);
        if (existingSupplier == null) {
            throw new Exception("Supplier not found with id: " + id);
        }
        // Aquí se marca el proveedor como "eliminado"
        existingSupplier.setEliminado(true);

        supplierService.update(existingSupplier);
    }

    // Metodo GET para obtener un proveedor por su ID
    public SupplierDto findById(int id) throws Exception {
        Supplier supplier = supplierService.findById(id);
        if (supplier == null) {
            throw new Exception("Supplier not found with id: " + id);
        }
        SupplierDto supplierDto = new SupplierDto();
        supplierDto.setId(supplier.getId());
        supplierDto.setNombreProveedor(supplier.getNombreProveedor());
        supplierDto.setApellidoProveedor(supplier.getApellidoProveedor());
        supplierDto.setIdentificacionProveedor(supplier.getIdentificacionProveedor());
        supplierDto.setEmailProveedor(supplier.getEmailProveedor());
        supplierDto.setTelefonoProveedor(supplier.getTelefonoProveedor());
        supplierDto.setEmpresaProveedor(supplier.getEmpresaProveedor());
        return supplierDto;
    }
}
