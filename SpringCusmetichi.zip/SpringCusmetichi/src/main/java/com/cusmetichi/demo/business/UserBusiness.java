package com.cusmetichi.demo.business;

import java.util.ArrayList;
import java.util.List;

import com.cusmetichi.demo.dtos.*;
import com.cusmetichi.demo.entity.*;
import com.cusmetichi.demo.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UserBusiness {

    @Autowired
    private UserService userService;

    @Autowired
    private RoleService roleService;

    private List<User> userList;

    // Método GET
    public List<UserDto> findAll() throws Exception {
        this.userList = this.userService.findAll();
        List<UserDto> userDtoList = new ArrayList<>();

        this.userList.forEach(user -> {
            UserDto userDto = new UserDto();
            userDto.setId(user.getId());
            userDto.setNombre(user.getNombre());
            userDto.setEmail(user.getEmail());
            userDto.setContraseña(user.getContraseña());

            // Mapeo de la llave foránea Role
            Role role = user.getFkid_rol();
            if (role != null) {
                RoleDto roleDto = new RoleDto();
                roleDto.setId(role.getId());
                roleDto.setNombre(role.getNombre());
                userDto.setFkid_rol(roleDto);
            }

            userDtoList.add(userDto);
        });

        return userDtoList;
    }

    // Método POST
    public void createUser(UserDto userDto) throws Exception {
        User user = new User();
        user.setNombre(userDto.getNombre());
        user.setEmail(userDto.getEmail());
        user.setContraseña(userDto.getContraseña());

        // Mapeo de la llave foránea Role
        RoleDto roleDto = userDto.getFkid_rol();
        Role role = roleService.findById(roleDto.getId());
        if (role == null) {
            throw new Exception("Role not found with id: " + roleDto.getId());
        }
        user.setFkid_rol(role);

        this.userService.create(user);
    }

    // Método PUT
    public void updatedUser(int id, UserDto updatedUserDto) throws Exception {
        User existingUser = userService.findById(id);
        if (existingUser == null) {
            throw new Exception("User not found with id: " + id);
        }

        // Actualización de los atributos simples del usuario
        existingUser.setContraseña(updatedUserDto.getContraseña());
        existingUser.setEmail(updatedUserDto.getEmail());
        existingUser.setNombre(updatedUserDto.getNombre());

        // Actualización de la llave foránea Role
        if (updatedUserDto.getFkid_rol() != null) {
            int roleId = updatedUserDto.getFkid_rol().getId();
            Role role = roleService.findById(roleId);
            if (role == null) {
                throw new Exception("Role not found with id: " + roleId);
            }
            existingUser.setFkid_rol(role);
        }

        userService.update(existingUser);
    }

    // Método DELETE
    public void deleteUser(int id) throws Exception {
        User existingUser = userService.findById(id);
        if (existingUser == null) {
            throw new Exception("User not found with id: " + id);
        }

        existingUser.setEliminado(true);
        userService.update(existingUser);
    }
}
