package com.cusmetichi.demo.controller;
import com.cusmetichi.demo.business.BrandBusiness;
import com.cusmetichi.demo.dtos.BrandDto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
@RequestMapping(path = "/api/brand", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@CrossOrigin("*")
public class BrandController {


    @Autowired
    private BrandBusiness brandBusiness;



    // Metodo GET
    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllBrand() throws Exception {
        Map<String ,Object> res = new HashMap<>();
        List<BrandDto> listBrandDto = this.brandBusiness.findAll();
        res.put("status" , "success");
        res.put("data", listBrandDto);
        return new ResponseEntity<>(res, HttpStatus.OK);
    }

    // Metodo POST
    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createBrand(@RequestBody BrandDto newBrand){
        Map<String, Object> res = new HashMap<>();
        try {
            brandBusiness.createBrand(newBrand);
            res.put("status", "sucess");
            res.put("data", newBrand);
            return new ResponseEntity<>(res, HttpStatus.CREATED);
        }catch (Exception e){
            res.put ("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Metodo PUT
    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateBrand(@PathVariable int id, @RequestBody BrandDto existingBrand) {
        Map<String, Object> res = new HashMap<>();
        try {
            brandBusiness.updatedBrand(id, existingBrand);
            if (existingBrand == null) {
                res.put("status", "error");
                res.put("message", "Brand not found");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }

            res.put("status", "success");
            res.put("data", existingBrand);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteBrand(@PathVariable int id) {
        try {
            brandBusiness.deleteBrand(id);
            return ResponseEntity.ok("Supplier marked as deleted");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }


}
















