package com.cusmetichi.demo.controller;
import com.cusmetichi.demo.business.CategoryBusiness;
import com.cusmetichi.demo.dtos.CategoryDto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/category", method = {RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST})
@CrossOrigin("*")
public class
CategoryController {

    @Autowired
    private CategoryBusiness categoryBusiness;


    // Metodo GET
    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllCategory() throws Exception {
        Map<String, Object> res = new HashMap<>();
        List<CategoryDto> listCategoryDto = this.categoryBusiness.findAll();
        res.put("status", "success");
        res.put("data", listCategoryDto);
        return new ResponseEntity<>(res, HttpStatus.OK);
    }


    // Metodo POST
    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createCategory(@RequestBody CategoryDto newCategory){
        Map<String, Object> res = new HashMap<>();
        try {
            categoryBusiness.createCategory(newCategory);
            res.put("status", "sucess");
            res.put("data", newCategory);
            return new ResponseEntity<>(res, HttpStatus.CREATED);
        }catch (Exception e){
            res.put ("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Metodo PUT
    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateCategory(@PathVariable int id, @RequestBody CategoryDto existingCategory) {
        Map<String, Object> res = new HashMap<>();
        try {
             categoryBusiness.updatedCategory(id, existingCategory);
            if (existingCategory== null) {
                res.put("status", "error");
                res.put("message", "Brand not found");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }
            existingCategory.setNombreCategoria(existingCategory.getNombreCategoria());
            res.put("status", "success");
            res.put("data", existingCategory);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteCategory(@PathVariable int id) {
        try {
            categoryBusiness.deleteCategory(id);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
}

