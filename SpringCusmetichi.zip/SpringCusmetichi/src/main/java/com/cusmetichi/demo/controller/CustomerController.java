package com.cusmetichi.demo.controller;
import com.cusmetichi.demo.business.CustomerBusiness;
import com.cusmetichi.demo.dtos.CustomerDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/customer", method = {RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST})
@CrossOrigin("*")
public class CustomerController {


    @Autowired
    private CustomerBusiness customerBusiness;
    private CustomerBusiness customerService;


    // Metodo GET
    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllCustomer() throws Exception {
        Map<String, Object> res = new HashMap<>();
        List<CustomerDto> listCustomerDto = this.customerBusiness.findAll();
        res.put("status", "success");
        res.put("data", listCustomerDto);
        return new ResponseEntity<>(res, HttpStatus.OK);
    }


    // Metodo POST
    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createCustomer(@RequestBody CustomerDto newCustomer) {
        Map<String, Object> res = new HashMap<>();
        try {
            customerBusiness.createCustomer(newCustomer);
            res.put("status", "sucess");
            res.put("data", newCustomer);
            return new ResponseEntity<>(res, HttpStatus.CREATED);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @GetMapping("/edit/{id}")
    public ResponseEntity<Map<String, Object>> getCustomerById(@PathVariable int id) {
        Map<String, Object> res = new HashMap<>();
        try {
            CustomerDto existingCustomer = customerService.findCustomerById(id);
            if (existingCustomer == null) {
                res.put("status", "error");
                res.put("message", "Cliente no encontrado");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }
            res.put("status", "success");
            res.put("data", existingCustomer);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteCustomer(@PathVariable int id) {
        try {
            customerBusiness.deleteCustomer(id);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
}









