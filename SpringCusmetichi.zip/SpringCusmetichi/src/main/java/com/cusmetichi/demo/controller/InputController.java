package com.cusmetichi.demo.controller;

import com.cusmetichi.demo.business.InputBusiness;
import com.cusmetichi.demo.dtos.InputDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/input", method = {RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST})
@CrossOrigin("*")
public class InputController {


    @Autowired
    private InputBusiness inputBusiness;


    // Metodo GET
    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllInput() throws Exception {
        Map<String, Object> res = new HashMap<>();
        List<InputDto> ListInputDto = this.inputBusiness.findAll();
        res.put("status", "success");
        res.put("data", ListInputDto);

        return new ResponseEntity<>(res, HttpStatus.OK);

    }


    // Metodo POST
    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createInput(@RequestBody InputDto newInput){
        Map<String, Object> res = new HashMap<>();
        try {
            inputBusiness.createInput(newInput);
            res.put("status", "sucess");
            res.put("data", newInput);
            return new ResponseEntity<>(res, HttpStatus.CREATED);
        }catch (Exception e){
            res.put ("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    // Metodo PUT
    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateInput(@PathVariable int id, @RequestBody InputDto existingInput) {
        Map<String, Object> res = new HashMap<>();
        try {
            inputBusiness.updatedInput(id, existingInput);
            if (existingInput == null) {
                res.put("status", "error");
                res.put("message", "Role not found");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }

            existingInput.setCantidadEntrada(existingInput.getCantidadEntrada());
            existingInput.setFechaEntrada(existingInput.getFechaEntrada());

            res.put("status", "success");
            res.put("data", existingInput);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteInput(@PathVariable int id) {
        try {
            inputBusiness.deleteInput(id);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
}










