package com.cusmetichi.demo.controller;
import com.cusmetichi.demo.business.InventoryBusiness;
import com.cusmetichi.demo.dtos.InventoryDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/inventory", method = {RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST})
@CrossOrigin("*")
public class InventoryController {



    @Autowired
    private InventoryBusiness inventoryBusiness;

    // Metodo GET
    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllInventory() throws Exception{
        Map<String, Object>res=new HashMap<>();
        List<InventoryDto> ListInventoryDto=this.inventoryBusiness.findAll();
        res.put("status", "succes");
        res.put("data", ListInventoryDto);
        return new ResponseEntity<>(res, HttpStatus.OK);
    }

    // Metodo POST
    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createInventory(@RequestBody InventoryDto newInventory){
        Map<String, Object> res = new HashMap<>();
        try {
            inventoryBusiness.createInventory(newInventory);
            res.put("status", "sucess");
            res.put("data", newInventory);
            return new ResponseEntity<>(res, HttpStatus.CREATED);
        }catch (Exception e){
            res.put ("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    // Metodo PUT
    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateInventory(@PathVariable int id, @RequestBody InventoryDto existingInventory) {
        Map<String, Object> res = new HashMap<>();
        try {
            inventoryBusiness.updatedInventory(id, existingInventory);
            if (existingInventory == null) {
                res.put("status", "error");
                res.put("message", "Inventory not found");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }
            res.put("status", "success");
            res.put("data", existingInventory);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
