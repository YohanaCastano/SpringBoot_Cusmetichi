package com.cusmetichi.demo.controller;
import com.cusmetichi.demo.business.OutputBusiness;
import com.cusmetichi.demo.dtos.OutputDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/output", method = {RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST})
@CrossOrigin("*")
public class OutputController {


    @Autowired
    private OutputBusiness outputBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllOutput() throws Exception{
        Map<String, Object>res=new HashMap<>();
        List<OutputDto> ListOutputDto=this.outputBusiness.findAll();
        res.put("status", "succes");
        res.put("data", ListOutputDto);

        return new ResponseEntity<>(res, HttpStatus.OK);
    }



    // Metodo POST
    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createOutput(@RequestBody OutputDto newOutput){
        Map<String, Object> res = new HashMap<>();
        try {
            outputBusiness.createOutput(newOutput);
            res.put("status", "sucess");
            res.put("data", newOutput);
            return new ResponseEntity<>(res, HttpStatus.CREATED);
        }catch (Exception e){
            res.put ("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    // Metodo PUT
    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateOutput(@PathVariable int id, @RequestBody OutputDto existingOutput) {
        Map<String, Object> res = new HashMap<>();
        try {
             outputBusiness.updatedOutput(id, existingOutput);
            if (existingOutput == null) {
                res.put("status", "error");
                res.put("message", "Role not found");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }
            res.put("status", "success");
            res.put("data", existingOutput);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteOutput(@PathVariable int id) {
        try {
            outputBusiness.deleteOutput(id);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
}



