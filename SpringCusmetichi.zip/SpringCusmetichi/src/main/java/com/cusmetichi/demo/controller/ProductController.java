package com.cusmetichi.demo.controller;
import com.cusmetichi.demo.business.ProductBusiness;
import com.cusmetichi.demo.dtos.ProductDto;

import com.cusmetichi.demo.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/product", method = {RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST})
@CrossOrigin("*")
public class ProductController {


    @Autowired
    private ProductBusiness productBusiness;
    private ProductRepository productoRepository;

    // Metodo GET
    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllProduct() throws Exception {
        Map<String, Object> res = new HashMap<>();
        List<ProductDto> ListProductDto = this.productBusiness.findAll();

        res.put("status", "success");
        res.put("data", ListProductDto);

        return new ResponseEntity<>(res, HttpStatus.OK);
    }


    // Metodo POST
    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createProduct(@RequestBody ProductDto newProduct) {
        Map<String, Object> res = new HashMap<>();
        try {
            productBusiness.createProduct(newProduct);
            res.put("status", "sucess");
            res.put("data", newProduct);
            return new ResponseEntity<>(res, HttpStatus.CREATED);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateProduct(@PathVariable int id, @RequestBody ProductDto existingProduct) {
        Map<String, Object> res = new HashMap<>();
        try {
             productBusiness.updatedProduct(id, existingProduct);
            if (existingProduct == null) {
                res.put("status", "error");
                res.put("message", "Role not found");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }
            res.put("status", "success");
            res.put("data", existingProduct);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteProduct(@PathVariable int id) {
        try {
            productBusiness.deleteProduct(id);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
}



