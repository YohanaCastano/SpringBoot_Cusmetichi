package com.cusmetichi.demo.controller;
import com.cusmetichi.demo.business.PurchaseSupplierBusiness;
import com.cusmetichi.demo.dtos.PurchaseSupplierDto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/purchaseSupplier", method = {RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST})
@CrossOrigin("*")
public class PurchaseSupplierController {

    @Autowired
    private PurchaseSupplierBusiness purchaseSupplierBusiness;


    // Metodo GET
    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllPurchaseSupplier() throws Exception {
        Map<String, Object> res = new HashMap<>();
        List<PurchaseSupplierDto> ListPurchaseSupplierDto = this.purchaseSupplierBusiness.findAll();
        res.put("status", "succes");
        res.put("data", ListPurchaseSupplierDto);

        return new ResponseEntity<>(res, HttpStatus.OK);
    }




    // Metodo POST
    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createPurchaseSupplier(@RequestBody PurchaseSupplierDto newPurchaseSupplier){
        Map<String, Object> res = new HashMap<>();
        try {
            purchaseSupplierBusiness.createPurchaseSupplier(newPurchaseSupplier);
            res.put("status", "sucess");
            res.put("data", newPurchaseSupplier);
            return new ResponseEntity<>(res, HttpStatus.CREATED);
        }catch (Exception e){
            res.put ("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }



    // Metodo PUT
    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updatePurchaseSupplier(@PathVariable int id, @RequestBody PurchaseSupplierDto existingPurchaseSupplier) {
        Map<String, Object> res = new HashMap<>();
        try {
             purchaseSupplierBusiness.updatedPurchaseSupplier(id, existingPurchaseSupplier);
            if (existingPurchaseSupplier == null) {
                res.put("status", "error");
                res.put("message", "Role not found");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }
            res.put("status", "success");
            res.put("data", existingPurchaseSupplier);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deletePurchaseSupplierFromList(@PathVariable int id) {
        try {
            purchaseSupplierBusiness.deletePurchaseSupplierFromList(id);
            return ResponseEntity.ok("Purchase supplier removed from the list successfully.");
        } catch (Exception e) {
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }
}



