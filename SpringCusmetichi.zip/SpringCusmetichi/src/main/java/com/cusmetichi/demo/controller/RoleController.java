package com.cusmetichi.demo.controller;
import com.cusmetichi.demo.business.RoleBusiness;
import com.cusmetichi.demo.dtos.RoleDto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/role", method = {RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST})
@CrossOrigin("*")
public class RoleController {


    @Autowired
    private RoleBusiness roleBusiness;

    // Metodo GET
    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllRole() throws Exception {
        Map<String, Object> res = new HashMap<>();
        List<RoleDto> ListRoleDto = this.roleBusiness.findAll();
        res.put("status", "succes");
        res.put("data", ListRoleDto);

        return new ResponseEntity<>(res, HttpStatus.OK);
    }



    // Metodo POST
    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createRole(@RequestBody RoleDto newRole){
        Map<String, Object> res = new HashMap<>();
        try {
            roleBusiness.createRole(newRole);
            res.put("status", "sucess");
            res.put("data", newRole);
            return new ResponseEntity<>(res, HttpStatus.CREATED);
        }catch (Exception e){
            res.put ("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }



    // Metodo PUT
    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateRole(@PathVariable int id, @RequestBody RoleDto existingRole) {
        Map<String, Object> res = new HashMap<>();
        try {
             roleBusiness.updatedRole(id, existingRole);
            if (existingRole == null) {
                res.put("status", "error");
                res.put("message", "Role not found");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }
            res.put("status", "success");
            res.put("data", existingRole);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


}
