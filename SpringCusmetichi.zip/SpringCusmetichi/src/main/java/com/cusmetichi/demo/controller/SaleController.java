package com.cusmetichi.demo.controller;
import com.cusmetichi.demo.business.SaleBusiness;
import com.cusmetichi.demo.dtos.SaleDto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/sale", method = {RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST})
@CrossOrigin("*")
public class SaleController {

    @Autowired
    private SaleBusiness saleBusiness;

    // Metodo GET
    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllSale() throws Exception{
        Map<String, Object>res=new HashMap<>();
        List<SaleDto> ListSaleDto=this.saleBusiness.findAll();
        res.put("status", "succes");
        res.put("data", ListSaleDto);

        return new ResponseEntity<>(res, HttpStatus.OK);
    }
    
    // Metodo POST
    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createSale(@RequestBody SaleDto newSale){
        Map<String, Object> res = new HashMap<>();
        try {
            saleBusiness.createSale(newSale);
            res.put("status", "sucess");
            res.put("data", newSale);
            return new ResponseEntity<>(res, HttpStatus.CREATED);
        }catch (Exception e){
            res.put ("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Metodo PUT
    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateSale(@PathVariable int id, @RequestBody SaleDto existingSale) {
        Map<String, Object> res = new HashMap<>();
        try {
            saleBusiness.updatedSale(id, existingSale);
            if (existingSale == null) {
                res.put("status", "error");
                res.put("message", "Role not found");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }
            res.put("status", "success");
            res.put("data", existingSale);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }
}
