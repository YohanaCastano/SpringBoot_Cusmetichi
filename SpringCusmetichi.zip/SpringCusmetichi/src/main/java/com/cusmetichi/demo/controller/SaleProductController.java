package com.cusmetichi.demo.controller;

import com.cusmetichi.demo.business.OutputBusiness;
import com.cusmetichi.demo.business.SaleProductBusiness;
import com.cusmetichi.demo.dtos.SaleProductDto;
import com.cusmetichi.demo.entity.SaleProduct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/sale_product", method = {RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST})
@CrossOrigin("*")

public class SaleProductController {

    @Autowired
    private SaleProductBusiness saleProductBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllSale_product() throws Exception{
        Map<String, Object>res=new HashMap<>();
        List<SaleProductDto> ListOutputDto=this.saleProductBusiness.findAll();
        res.put("status", "succes");
        res.put("data", ListOutputDto);

        return new ResponseEntity<>(res, HttpStatus.OK);
    }


    // Metodo POST
    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createSaleProduct(@RequestBody SaleProductDto newSaleProduct){
        Map<String, Object> res = new HashMap<>();
        try {
            saleProductBusiness.createSaleProduct(newSaleProduct);
            res.put("status", "sucess");
            res.put("data", newSaleProduct);
            return new ResponseEntity<>(res, HttpStatus.CREATED);
        }catch (Exception e){
            res.put ("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Metodo PUT
    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateSaleProduct(@PathVariable int id, @RequestBody SaleProductDto existingsaleproduct) {
        Map<String, Object> res = new HashMap<>();
        try {
            saleProductBusiness.updatedSaleProduct(id, existingsaleproduct);
            if (existingsaleproduct == null) {
                res.put("status", "error");
                res.put("message", "Role not found");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }

            existingsaleproduct.setCantidad(existingsaleproduct.getCantidad());


            res.put("status", "success");
            res.put("data", existingsaleproduct);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}





