package com.cusmetichi.demo.controller;

import com.cusmetichi.demo.business.SupplierBusiness;
import com.cusmetichi.demo.dtos.SupplierDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/supplier")
@CrossOrigin("*")
public class SupplierController {

    @Autowired
    private SupplierBusiness supplierBusiness;

    // Metodo GET para obtener todos los proveedores
    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllSupplier() throws Exception {
        Map<String, Object> res = new HashMap<>();
        List<SupplierDto> ListSupplierDto = this.supplierBusiness.findAll();
        res.put("status", "success");
        res.put("data", ListSupplierDto);

        return new ResponseEntity<>(res, HttpStatus.OK);
    }

    // Metodo GET para obtener un proveedor por su ID
    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> getSupplierById(@PathVariable int id) {
        Map<String, Object> res = new HashMap<>();
        try {
            SupplierDto supplier = supplierBusiness.findById(id);
            if (supplier == null) {
                res.put("status", "error");
                res.put("message", "Supplier not found");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }
            res.put("status", "success");
            res.put("data", supplier);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Metodo POST
    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createSupplier(@RequestBody SupplierDto newSupplier) {
        Map<String, Object> res = new HashMap<>();
        try {
            supplierBusiness.createSupplier(newSupplier);
            res.put("status", "success");
            res.put("data", newSupplier);
            return new ResponseEntity<>(res, HttpStatus.CREATED);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Metodo PUT
    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateSupplier(@PathVariable int id, @RequestBody SupplierDto existingSupplier) {
        Map<String, Object> res = new HashMap<>();
        try {
             supplierBusiness.updatedSupplier(id, existingSupplier);
            if (existingSupplier == null) {
                res.put("status", "error");
                res.put("message", "Supplier not found");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }
            res.put("status", "success");
            res.put("data", existingSupplier);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Metodo DELETE
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteSupplier(@PathVariable int id) {
        try {
            supplierBusiness.deleteSupplier(id);
            return ResponseEntity.ok("Supplier marked as deleted");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
}
