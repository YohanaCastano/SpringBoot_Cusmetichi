package com.cusmetichi.demo.controller;
import com.cusmetichi.demo.business.UserBusiness;
import com.cusmetichi.demo.dtos.UserDto;
import com.cusmetichi.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/user", method = {RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST})
@CrossOrigin("*")
public class UserController {

    @Autowired
    private UserBusiness userBusiness;
    private UserRepository userRepository;

    // Metodo GET
    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllUser() throws Exception{
        Map<String, Object> res = new HashMap<>();
        List<UserDto> ListUserDto = this.userBusiness.findAll();
        res.put("status", "succes");
        res.put("data", ListUserDto);

        return new ResponseEntity<>(res, HttpStatus.OK);
    }

    // Metodo POST
    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createUser(@RequestBody UserDto newUser){
        Map<String, Object> res = new HashMap<>();
        try {
            userBusiness.createUser(newUser);
            res.put("status", "sucess");
            res.put("data", newUser);
            return new ResponseEntity<>(res, HttpStatus.CREATED);
        }catch (Exception e){
            res.put ("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    // Metodo PUT
    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateUser(@PathVariable int id, @RequestBody UserDto existingUser) {
        Map<String, Object> res = new HashMap<>();
        try {
            userBusiness.updatedUser(id, existingUser);
            if (existingUser == null) {
                res.put("status", "error");
                res.put("message", "User not found");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }
            res.put("status", "success");
            res.put("data", existingUser);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable int id) {
        try {
            userBusiness.deleteUser(id);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
}


