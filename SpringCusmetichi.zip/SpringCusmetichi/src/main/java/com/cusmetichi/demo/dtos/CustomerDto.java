package com.cusmetichi.demo.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerDto {

    private int id;
    private String NombreCliente;
    private String ApellidoCliente;
    private Long IdentificacionClientes;
    private String EmailCliente;
    private Long TelCliente;
    private String DireccionCliente;

    private UserDto fkid_user;

    public void setFkid_user(UserDto userDto) {
    }
}
