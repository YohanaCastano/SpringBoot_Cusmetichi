package com.cusmetichi.demo.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InventoryDto {

    private int id;
    private int CantidadProducto;


    // Llave Foranea
    private InputDto fkidInput;
    private OutputDto fkidOutput;
    private ProductDto fkid_Product;


}
