package com.cusmetichi.demo.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OutputDto {

    private int id;
    private int CantidadSalidas;
    private String TipoSalida;
    private LocalDate FechaSalida;
    private double IvaTotal;
    private String MetodoPago;


}
