package com.cusmetichi.demo.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.web.multipart.MultipartFile;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductDto {
    private int id;
    private String nombreProducto;
    private String tamañoProducto;
    private String descripcionProducto;
    private double precioProducto;
    private double ivaProducto;
    private int cantidadProducto;
    private double subtotal;
    private String imagen;

    // Llave foránea
    private SupplierDto fkidProveedor;
    private InventoryDto fkidInventario;
    private CategoryDto fkid_category;
    private BrandDto fkid_brand;

}
