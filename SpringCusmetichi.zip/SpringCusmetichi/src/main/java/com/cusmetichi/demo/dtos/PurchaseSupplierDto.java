package com.cusmetichi.demo.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PurchaseSupplierDto {

    private int id;
    private int CantidadProducto;
    private String EstadoPedido;
    private LocalDate FechaPedido;
    private double CostoProducto;


    // Llaves foraneas
    private SupplierDto fkidProveedor;

}
