package com.cusmetichi.demo.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SaleDto {

    private int id;
    private Date fecha;
    private int Cantidad;
    private double IvaTotal;
    private double Total;
}
