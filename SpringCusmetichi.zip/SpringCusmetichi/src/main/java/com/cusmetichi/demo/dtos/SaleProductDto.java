package com.cusmetichi.demo.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class SaleProductDto {
    private int Id;
    private SaleDto fkid_sale;
    private ProductDto fkid_product;
    private int cantidad;
}
