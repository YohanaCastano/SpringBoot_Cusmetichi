package com.cusmetichi.demo.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDto {

    private int id;
    private String Nombre;
    private String Email;
    private String Contraseña;

    // Llave Foranea

    private RoleDto fkid_rol;

}
