package com.cusmetichi.demo.entity;
import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Entity
@Table(name= "Marcas")
@Data
public class Brand implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int id;

    @Column(name= "NombreMarca", length = 45)
    String NombreMarca;



    // Relaciones

   @JsonBackReference
   @OneToMany(mappedBy = "fkid_brand")
   private List<Product>productList;

    public void setEliminado(boolean b) {
    }
}
