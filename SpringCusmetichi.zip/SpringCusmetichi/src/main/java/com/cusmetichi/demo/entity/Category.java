package com.cusmetichi.demo.entity;
import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Entity
@Table(name= "Categorias")
@Data
public class Category implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int id;

    @Column(name = "NombreCategoria", length = 45)
    String NombreCategoria;

    @JsonBackReference
    @OneToMany(mappedBy = "fkid_category")
    private List<Product> productList;

    public void setEliminado(boolean b) {
    }
}
