package com.cusmetichi.demo.entity;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Entity
@Table(name= "Clientes")
@Data
public class Customer implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int id;

    @Column(name= "NombreCliente", length = 45)
    String NombreCliente;
    @Column(name= "ApellidoCliente", length = 45)
    String ApellidoCliente;

    @Column(name= "IdentificacionCliente")
    Long IdentificacionClientes;

    @Column(name= "EmailCliente", length = 45)
    String EmailCliente;

    @Column(name= "TelCliente")
    Long TelCliente;

    @Column(name= "DireccionCliente", length = 45)
    String DireccionCliente;

    @JsonManagedReference
    @ManyToOne
    @JoinColumn(name = "fkid_user")
    private User fkid_user;

    public void setEliminado(boolean b) {
    }
}
