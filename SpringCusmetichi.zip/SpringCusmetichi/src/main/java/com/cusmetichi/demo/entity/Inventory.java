package com.cusmetichi.demo.entity;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "Inventarios")
@Data
public class Inventory implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int id;

    @Column(name= "CantidadProducto")
    int CantidadProducto;

    //Relaciones

    @JsonManagedReference
    @ManyToOne
    @JoinColumn(name = "fkid_product")
    private Product fkid_product;

    @JsonManagedReference
    @ManyToOne
    @JoinColumn(name= "fkidInput")
    private Input fkidInput;

    @JsonManagedReference
    @ManyToOne
    @JoinColumn(name= "fkidOutput")
    private Output fkidOutput;
}
