package com.cusmetichi.demo.entity;
import java.io.Serializable;
import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Data;

@Entity
@Table(name= "Salidas")
@Data
public class Output implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int Id;

    @Column(name= "CantidadSalidas")
    int CantidadSalidas;

    @Column(name= "TipoSalida", length = 45)
    String TipoSalida;

    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyy-MM-dd")
    @Column(name= "FechaSalida")
    LocalDate FechaSalida;

    @Column(name= "IvaTotal")
    double IvaTotal;

    @Column(name= "MetodoPago")
    String MetodoPago;




    // Relaciones





    public void setEliminado(boolean b) {
    }
}
