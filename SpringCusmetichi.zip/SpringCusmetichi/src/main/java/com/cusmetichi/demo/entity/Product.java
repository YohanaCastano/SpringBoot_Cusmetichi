package com.cusmetichi.demo.entity;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Entity
@Table(name= "Productos")
@Data
public class Product   implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int id;
    @Column(name= "NombreProducto", length = 45)
    String NombreProducto;
    @Column(name= "TamañoProducto", length = 45)
    String TamañoProducto;
    @Column(name= "DescripcionProducto", length = 45)
    String  DescripcionProducto;
    @Column(name= "PrecioProducto")
    double PrecioProducto;
    @Column(name= "IvaProducto")
    double IvaProducto;
    @Column(name= "CantidadProducto")
    int CantidadProducto;
    @Column(name = "imagen")
    String imagen;
    // Relaciones

    @JsonManagedReference
    @ManyToOne
    @JoinColumn(name= "fkidProveedor")
    private Supplier fkidProveedor;


    @JsonBackReference
    @OneToMany(mappedBy = "fkid_product")
    private List<Inventory> inventoryList;


   @JsonManagedReference
   @ManyToOne
   @JoinColumn(name = "fkid_brand")
   private Brand fkid_brand;


    @JsonManagedReference
    @ManyToOne
    @JoinColumn(name = "fkid_category")
    private Category fkid_category;



    public void setEliminado(boolean b) {
    }
}
