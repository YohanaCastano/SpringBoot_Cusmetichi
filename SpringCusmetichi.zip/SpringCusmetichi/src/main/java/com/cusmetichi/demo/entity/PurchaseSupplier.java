package com.cusmetichi.demo.entity;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.time.LocalDate;

@Entity
@Table(name= "CompraProveedor")
@Data
public class PurchaseSupplier implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int id;

    @Column(name= "CantidadProducto")
    int CantidadProducto;

    @Column(name= "EstadoPedido", length = 45)
    String EstadoPedido;

    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyy-MM-dd")
    @Column(name= "FechaPedido")
    LocalDate FechaPedido;

    @Column(name= "CostoProducto")
    double CostoProducto;


    // Relaciones

    @JsonManagedReference
    @ManyToOne
    @JoinColumn(name= "fkidProveedor")
    private Supplier fkidProveedor;

}
