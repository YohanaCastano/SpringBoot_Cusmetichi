package com.cusmetichi.demo.entity;
import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name= "Rol")
@Data
public class Role implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int id;

    @Column(name= "nombre")
    String  nombre;

    @JsonBackReference
    @OneToMany(mappedBy = "fkid_rol")
    private List<User> userList;


}
