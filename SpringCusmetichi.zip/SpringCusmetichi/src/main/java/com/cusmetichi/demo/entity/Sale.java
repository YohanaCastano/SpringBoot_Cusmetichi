package com.cusmetichi.demo.entity;
import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Entity
@Table(name= "Ventas")
@Data
public class Sale implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(name="Fecha")
    private Date fecha;
    @Column(name="Cantidad")
    private int Cantidad;
    @Column(name= "IvaTotal")
    private double IvaTotal;
    @Column(name= "Total")
    private double Total;

    // Relaciones

    @JsonBackReference
    @OneToMany(mappedBy = "fkid_sale")
    private List<SaleProduct> saleProductList;
}
