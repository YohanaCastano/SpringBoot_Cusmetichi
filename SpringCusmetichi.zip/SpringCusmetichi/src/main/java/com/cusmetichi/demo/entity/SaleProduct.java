package com.cusmetichi.demo.entity;


import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table (name = "sale_product")
@Data
public class SaleProduct {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private int Id;

    @JsonManagedReference
    @ManyToOne
    @JoinColumn(name = "fkid_sale")
    private Sale fkid_sale;

    @JsonManagedReference
    @ManyToOne
    @JoinColumn(name = "fkid_product")
    private Product fkid_product;

    @Column (name = "cantidad", length = 4)
    private int cantidad;

}

