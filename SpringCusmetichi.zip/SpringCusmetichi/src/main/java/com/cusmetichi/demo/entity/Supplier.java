package com.cusmetichi.demo.entity;
import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;


import java.io.Serializable;
import java.util.List;

@Entity
@Table(name= "Proveedores")
@Data
public class Supplier implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int id;


    @Column(name= "NombreProveedor", length = 45)
    String NombreProveedor;

    @Column(name= "ApellidoProveedor", length = 45)
    String ApellidoProveedor;

    @Column(name= "IdentificacionProveedor")
    Long IdentificacionProveedor;

    @Column(name= "EmailProveedor", length = 45)
    String EmailProveedor;

    @Column(name= "TelefonoProveedor")
    Long TelefonoProveedor;

    @Column(name= "EmpresaProveedor", length = 45)
    String EmpresaProveedor;



    // Relaciones

    @JsonBackReference
    @OneToMany(mappedBy = "fkidProveedor")
    private List<PurchaseSupplier> purchaseSupplierList;

    @JsonBackReference
    @OneToMany(mappedBy = "fkidProveedor")
    private List<Product>productList;


    public void setVisible(boolean b) {
    }

    public void setEliminado(boolean b) {
    }
}
