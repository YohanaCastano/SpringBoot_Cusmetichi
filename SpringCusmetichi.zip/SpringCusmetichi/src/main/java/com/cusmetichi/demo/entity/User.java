package com.cusmetichi.demo.entity;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;

import java.io.Serializable;
import java.util.List;


@Entity
@Table(name= "Usuarios")
@Data
public class User implements Serializable {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int id;

    @Column(name= "Nombre", length = 45)
    String Nombre;

    @Column(name= "Email", length = 45)
    String Email;

    @Column(name= "Contraseña", length = 45)
    String Contraseña;


    // Relaciones

    @JsonBackReference
    @OneToMany(mappedBy = "fkid_user")
    private List<Customer>customerList;

    @JsonManagedReference
    @ManyToOne
    @JoinColumn(name= "fkid_rol")
    private Role fkid_rol;

    public void setEliminado(boolean b) {
    }
}
