package com.cusmetichi.demo.repository;

import com.cusmetichi.demo.entity.Brand;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface BrandRepository extends JpaRepository<Brand,Integer> {
        @Query(value="select b From Brand b where b.id=:id")
        public Brand findById(int id);
}