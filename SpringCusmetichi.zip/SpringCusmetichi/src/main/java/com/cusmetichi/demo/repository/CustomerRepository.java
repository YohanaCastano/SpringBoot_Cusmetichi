package com.cusmetichi.demo.repository;


import com.cusmetichi.demo.entity.Customer;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;


    @Repository
    public interface CustomerRepository extends JpaRepository <Customer,Integer>{

        @Query(value="select cu From Customer cu where cu.id=:id")
        public Customer findById(int id);
    }
