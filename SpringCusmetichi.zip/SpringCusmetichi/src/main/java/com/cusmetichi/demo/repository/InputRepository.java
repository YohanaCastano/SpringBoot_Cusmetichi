package com.cusmetichi.demo.repository;

import com.cusmetichi.demo.entity.Input;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;


    @Repository
    public interface InputRepository extends JpaRepository<Input,Integer> {

        @Query(value="select i From Input i where i.id=:id")
        public Input findById(int id);
    }

