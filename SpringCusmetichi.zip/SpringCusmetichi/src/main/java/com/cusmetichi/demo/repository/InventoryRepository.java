package com.cusmetichi.demo.repository;
import com.cusmetichi.demo.entity.Inventory;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;



    @Repository
    public interface InventoryRepository extends JpaRepository<Inventory,Integer> {

        @Query(value="select i From Inventory i where i.id=:id")
        public Inventory findById(int id);
    }

