package com.cusmetichi.demo.repository;

import com.cusmetichi.demo.entity.Output;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;





    @Repository
    public interface OutputRepository extends JpaRepository<Output, Integer> {

        @Query(value = "select o From Output o where o.id=:id")
        public Output findAllBy(int id);

    }


