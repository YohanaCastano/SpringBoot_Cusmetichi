package com.cusmetichi.demo.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cusmetichi.demo.entity.PurchaseSupplier;

    @Repository
    public interface PurchaseSupplierRepository extends JpaRepository<PurchaseSupplier, Integer> {

        @Query(value="select ps From PurchaseSupplier ps where ps.id=:id")
        public PurchaseSupplier findById(int id);
    }
