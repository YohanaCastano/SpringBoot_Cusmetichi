package com.cusmetichi.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cusmetichi.demo.entity.Sale;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;



    @Repository
    public interface SaleRepository extends JpaRepository <Sale, Integer>{

        @Query(value="select s From Sale s where s.id=:id")
        public Sale findById(int id);

    }
