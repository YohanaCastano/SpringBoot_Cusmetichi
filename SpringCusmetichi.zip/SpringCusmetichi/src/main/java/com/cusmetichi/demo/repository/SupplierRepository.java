package com.cusmetichi.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cusmetichi.demo.entity.Supplier;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;




    @Repository
    public interface SupplierRepository extends JpaRepository<Supplier, Integer>{


        @Query(value="select su From Supplier su where su.id=:id")
        public Supplier findById(int id);
    }
