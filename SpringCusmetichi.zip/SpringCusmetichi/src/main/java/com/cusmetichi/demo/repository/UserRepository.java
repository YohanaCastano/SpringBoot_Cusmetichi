package com.cusmetichi.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cusmetichi.demo.entity.User;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


    @Repository
    public interface UserRepository extends JpaRepository<User, Integer>{

        @Query(value="select u From User u where u.id=:id")
        public User findById(int id);

    }
