package com.cusmetichi.demo.service;
import com.cusmetichi.demo.entity.Brand;
import java.util.List;

public interface BrandService {
    List<Brand> findAll() throws Exception;

    Brand findById(int id);

    void create(Brand brand);
    void update(Brand brand);
    void delete(Brand brand);

}
