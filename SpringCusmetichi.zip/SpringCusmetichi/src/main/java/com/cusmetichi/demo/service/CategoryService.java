package com.cusmetichi.demo.service;
import com.cusmetichi.demo.entity.Category;
import java.util.List;

public interface CategoryService {
    List<Category> findAll() throws Exception;

    Category findById(int id);

    void create(Category category);
    void update(Category category);
    void delete(Category category);


}
