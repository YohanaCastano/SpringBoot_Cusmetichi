package com.cusmetichi.demo.service;
import com.cusmetichi.demo.entity.Brand;
import com.cusmetichi.demo.entity.Customer;

import java.util.List;

public interface CustomerService {
    List<Customer> findAll() throws Exception;

    Customer findById(int id);
    void create(Customer customer);
    void update(Customer customer);
    void delete(Customer customer);
}

