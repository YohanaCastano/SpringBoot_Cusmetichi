package com.cusmetichi.demo.service;
import com.cusmetichi.demo.entity.Input;
import java.util.List;

public interface InputService {
    List<Input> findAll() throws Exception;
    Input findById(int id);

    void create(Input input);
    void update(Input input);
    void delete(Input input);
}
