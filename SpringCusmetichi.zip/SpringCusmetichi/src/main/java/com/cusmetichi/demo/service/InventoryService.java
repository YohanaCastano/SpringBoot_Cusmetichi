package com.cusmetichi.demo.service;

import com.cusmetichi.demo.entity.Inventory;

import java.util.List;

public interface InventoryService {
    List<Inventory> findAll() throws Exception;
    Inventory findById(int id);

    void create(Inventory inventory);
    void update(Inventory inventory);
    void delete(Inventory inventory);
}
