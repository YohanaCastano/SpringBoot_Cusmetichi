package com.cusmetichi.demo.service;

import com.cusmetichi.demo.entity.Output;

import java.util.List;

public interface OutPutService {
    List<Output>findAll() throws Exception;
    Output findById(int id);

    void create(Output output);
    void update(Output output);
    void delete(Output output);
}
