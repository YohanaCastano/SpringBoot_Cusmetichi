package com.cusmetichi.demo.service;
import java.util.List;
import com.cusmetichi.demo.entity.Product;

public interface ProductService {

     List<Product> findAll();
     Product findById(int id);

     void create(Product product);
     void update(Product product);
     void delete(Product product);
}
