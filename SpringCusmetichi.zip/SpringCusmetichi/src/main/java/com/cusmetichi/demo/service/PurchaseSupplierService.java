package com.cusmetichi.demo.service;

import java.util.List;

import com.cusmetichi.demo.entity.PurchaseSupplier;

public interface PurchaseSupplierService {
    List<PurchaseSupplier> findAll() throws Exception;
    PurchaseSupplier findById(int id);

    void create(PurchaseSupplier purchaseSupplier);
    void update(PurchaseSupplier purchaseSupplier);
    void delete(PurchaseSupplier purchaseSupplier);
}
