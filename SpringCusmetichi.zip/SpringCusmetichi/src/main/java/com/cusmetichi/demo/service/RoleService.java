package com.cusmetichi.demo.service;

import com.cusmetichi.demo.entity.Role;
import java.util.List;

public interface RoleService {
    List<Role> findAll() throws Exception;
    Role findById(int id);

    void create (Role role);
    void update (Role role);
    void delete (Role role);


}
