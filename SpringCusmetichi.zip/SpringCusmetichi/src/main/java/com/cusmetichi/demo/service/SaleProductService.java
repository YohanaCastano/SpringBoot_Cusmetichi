package com.cusmetichi.demo.service;

import java.util.List;
import com.cusmetichi.demo.entity.SaleProduct;
public interface SaleProductService {
    List<SaleProduct> findAll();

    SaleProduct findById(int Id);

    void create(SaleProduct sale_product);

    void update(SaleProduct sale_product);

    void delete(SaleProduct sale_product);
}
