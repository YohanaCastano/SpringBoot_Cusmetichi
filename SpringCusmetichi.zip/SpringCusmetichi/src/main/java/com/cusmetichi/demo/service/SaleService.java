package com.cusmetichi.demo.service;

import com.cusmetichi.demo.entity.Sale;

import java.util.List;

public interface SaleService {
    List<Sale>findAll() throws Exception;
    Sale findById(int id);

    void create(Sale sale);
    void update (Sale sale);
    void delete (Sale sale);

}
