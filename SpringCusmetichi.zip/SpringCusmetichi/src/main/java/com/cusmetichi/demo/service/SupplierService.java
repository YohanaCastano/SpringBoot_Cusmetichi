package com.cusmetichi.demo.service;
import com.cusmetichi.demo.entity.Supplier;
import java.util.List;

public interface SupplierService {
    List<Supplier>findAll() throws Exception;
    Supplier findById(int id);

    void create(Supplier supplier);
    void update (Supplier supplier);
    void delete(Supplier supplier);
}
