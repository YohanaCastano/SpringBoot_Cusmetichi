package com.cusmetichi.demo.service;

import com.cusmetichi.demo.entity.User;

import java.util.List;

public interface UserService {
    List<User>findAll() ;
    User findById(int id);

    void create(User user);
    void update (User user);
    void delete(User user);
}

