package com.cusmetichi.demo.service.imp;

import com.cusmetichi.demo.entity.Brand;
import com.cusmetichi.demo.repository.BrandRepository;
import com.cusmetichi.demo.service.BrandService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BrandImp implements BrandService {

    @Autowired
    private BrandRepository brandRepository;

    @Override
    public List<Brand> findAll() {
        return brandRepository.findAll();
    }

    @Override
    public Brand findById(int id) {
        Brand brand = this.brandRepository.findById(id);
        return brand;
    }

    @Override
    public void create(Brand brand) {
        this.brandRepository.save(brand);
    }

    @Override
    public void update(Brand brand) {
        this.brandRepository.save(brand);
    }

    @Override
    public void delete(Brand brand) {
        this.brandRepository.delete(brand);
    }

}


