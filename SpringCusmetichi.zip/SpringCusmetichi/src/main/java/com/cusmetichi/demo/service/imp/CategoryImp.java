package com.cusmetichi.demo.service.imp;
import com.cusmetichi.demo.entity.Category;
import com.cusmetichi.demo.repository.CategoryRepository;
import com.cusmetichi.demo.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryImp implements CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    @Override
    public List<Category> findAll() throws Exception {
        return categoryRepository.findAll();
    }

    @Override
    public Category findById(int id) {
        Category category = this.categoryRepository.findById(id);
        return category;
    }

    @Override
    public void create(Category category) {
        this.categoryRepository.save(category);
    }

    @Override
    public void update(Category category) {
        this.categoryRepository.save(category);
    }

    @Override
    public void delete(Category category) {
        this.categoryRepository.delete(category);
    }
}
