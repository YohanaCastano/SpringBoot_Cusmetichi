package com.cusmetichi.demo.service.imp;

import com.cusmetichi.demo.entity.Customer;
import com.cusmetichi.demo.repository.CustomerRepository;
import com.cusmetichi.demo.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerImp implements CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public List<Customer> findAll() throws Exception {
        return customerRepository.findAll();
    }

    @Override
    public Customer findById(int id) {
        Customer customer = this.customerRepository.findById(id);
        return customer;
    }

    @Override
    public void create(Customer customer) {
        this.customerRepository.save(customer);
    }

    @Override
    public void update(Customer customer) {
        this.customerRepository.save(customer);
    }

    @Override
    public void delete(Customer customer) {
        this.customerRepository.delete(customer);
    }

}
