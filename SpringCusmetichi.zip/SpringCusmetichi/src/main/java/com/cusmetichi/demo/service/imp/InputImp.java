package com.cusmetichi.demo.service.imp;
import com.cusmetichi.demo.entity.Input;
import com.cusmetichi.demo.entity.Supplier;
import com.cusmetichi.demo.repository.InputRepository;
import com.cusmetichi.demo.service.InputService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InputImp implements InputService {

    @Autowired
    private InputRepository inputRepository;

    @Override
    public List<Input> findAll() throws Exception {
        return inputRepository.findAll();
    }

    @Override
    public Input findById(int id) {
        Input input = this.inputRepository.findById(id);
        return input;
    }

    @Override
    public void create(Input input) {
        this.inputRepository.save(input);
    }

    @Override
    public void update(Input input) {
        this.inputRepository.save(input);
    }

    @Override
    public void delete(Input input) {
        this.inputRepository.delete(input);
    }
}
