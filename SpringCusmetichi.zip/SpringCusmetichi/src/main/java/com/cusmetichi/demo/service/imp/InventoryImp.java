package com.cusmetichi.demo.service.imp;
import com.cusmetichi.demo.entity.Inventory;
import com.cusmetichi.demo.entity.Supplier;
import com.cusmetichi.demo.repository.InventoryRepository;
import com.cusmetichi.demo.service.InventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class InventoryImp implements InventoryService {

    @Autowired
    private InventoryRepository inventoryRepository;

    @Override
    public List<Inventory> findAll() throws Exception {
        return inventoryRepository.findAll();
    }

    @Override
    public Inventory findById(int id) {

        Inventory inventory = this.inventoryRepository.findById(id);
        return inventory;
    }

    @Override
    public void create(Inventory inventory) {
        this.inventoryRepository.save(inventory);
    }

    @Override
    public void update(Inventory inventory) {
        this.inventoryRepository.save(inventory);
    }

    @Override
    public void delete(Inventory inventory) {
        this.inventoryRepository.delete(inventory);

    }
}