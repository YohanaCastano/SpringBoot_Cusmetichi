package com.cusmetichi.demo.service.imp;

import com.cusmetichi.demo.entity.Output;
import com.cusmetichi.demo.repository.OutputRepository;
import com.cusmetichi.demo.service.OutPutService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OutputImp  implements OutPutService {

    @Autowired
    private OutputRepository outputRepository;

    @Override
    public List<Output> findAll() throws Exception {
        return outputRepository.findAll();
    }

    @Override
    public Output findById(int id) {
        Output output = this.outputRepository.findAllBy(id);
        return  output;
    }

    @Override
    public void create(Output output) {
        this.outputRepository.save(output);
    }


    @Override
    public void update(Output output) {
        this.outputRepository.save(output);
    }

    @Override
    public void delete(Output output) {
        this.outputRepository.delete(output);
    }
}
