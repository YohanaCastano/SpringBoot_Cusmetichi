package com.cusmetichi.demo.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cusmetichi.demo.entity.PurchaseSupplier;
import com.cusmetichi.demo.repository.PurchaseSupplierRepository;
import com.cusmetichi.demo.service.PurchaseSupplierService;

@Service
public class PurchaseSupplierImp implements PurchaseSupplierService {

    @Autowired
    private PurchaseSupplierRepository purchaseSupplierRepository;

    @Override
    public List<PurchaseSupplier> findAll() throws Exception {
        return this.purchaseSupplierRepository.findAll();

    }

    @Override
    public PurchaseSupplier findById(int id) {
        PurchaseSupplier purchaseSupplier = this.purchaseSupplierRepository.findById(id);
        return purchaseSupplier;
    }

    @Override
    public void create(PurchaseSupplier purchaseSupplier) {
        this.purchaseSupplierRepository.save(purchaseSupplier);
    }

    @Override
    public void update(PurchaseSupplier purchaseSupplier) {
        this.purchaseSupplierRepository.save(purchaseSupplier);
    }

    @Override
    public void delete(PurchaseSupplier purchaseSupplier) {
        this.purchaseSupplierRepository.delete(purchaseSupplier);
    }
}
