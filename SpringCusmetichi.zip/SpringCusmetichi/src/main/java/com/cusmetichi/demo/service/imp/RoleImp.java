package com.cusmetichi.demo.service.imp;

import com.cusmetichi.demo.entity.Role;
import com.cusmetichi.demo.repository.RoleRepository;
import com.cusmetichi.demo.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleImp implements RoleService {

    @Autowired
    private RoleRepository roleRepository;

    @Override
    public List<Role> findAll()  throws Exception{
        return roleRepository.findAll();
    }

    @Override
    public Role findById(int id) {
        Role role = this.roleRepository.findById(id);
        return role;
    }

    @Override
    public void create(Role role) {
        this.roleRepository.save(role);
    }

    @Override
    public void update(Role role) {
        this.roleRepository.save(role);
    }

    @Override
    public void delete(Role role) {
        this.roleRepository.delete(role);
    }

}
