package com.cusmetichi.demo.service.imp;

import com.cusmetichi.demo.entity.Sale;
import com.cusmetichi.demo.repository.SaleRepository;
import com.cusmetichi.demo.service.SaleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class SaleImp  implements SaleService {


    @Autowired
    private SaleRepository saleRepository;

    @Override
    public List<Sale> findAll() throws Exception {
        return saleRepository.findAll();
    }

    @Override
    public Sale findById(int id) {
        Sale sale = this.saleRepository.findById(id);
        return sale;
    }

    @Override
    public void create(Sale sale) {
        this.saleRepository.save(sale);
    }

    @Override
    public void update(Sale sale) {
        this.saleRepository.save(sale);
    }

    @Override
    public void delete(Sale sale) {
        this.saleRepository.delete(sale);
    }
}
