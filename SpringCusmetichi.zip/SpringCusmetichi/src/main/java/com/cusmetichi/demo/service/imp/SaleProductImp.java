package com.cusmetichi.demo.service.imp;

import java.util.List;
import java.util.Optional;

import com.cusmetichi.demo.repository.SaleProductRepository;
import com.cusmetichi.demo.service.SaleProductService;
import com.cusmetichi.demo.entity.SaleProduct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class SaleProductImp implements SaleProductService {

    @Autowired
    private SaleProductRepository sale_ProductRepository;

    @Override
    public List<SaleProduct> findAll() {
        return this.sale_ProductRepository.findAll();
    }

    @Override
    public SaleProduct findById(int Id) {
        Optional<SaleProduct> saleProduct = this.sale_ProductRepository.findById(Id);
        return saleProduct.orElse(null);
    }

    @Override
    public void create(SaleProduct saleProduct) {
        this.sale_ProductRepository.save(saleProduct);
    }

    @Override
    public void update(SaleProduct saleProduct) {
        this.sale_ProductRepository.save(saleProduct);
    }

    @Override
    public void delete(SaleProduct saleProduct) {
        this.sale_ProductRepository.delete(saleProduct);
    }

}
