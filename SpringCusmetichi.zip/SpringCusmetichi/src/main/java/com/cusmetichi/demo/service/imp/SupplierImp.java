package com.cusmetichi.demo.service.imp;

import com.cusmetichi.demo.entity.Supplier;
import com.cusmetichi.demo.repository.SupplierRepository;
import com.cusmetichi.demo.service.SupplierService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SupplierImp  implements SupplierService {


    @Autowired
    private SupplierRepository supplierRepository;

    @Override
    public List<Supplier> findAll() throws Exception {
        return supplierRepository.findAll();
    }

    @Override
    public Supplier findById(int id) {
        Supplier supplier = this.supplierRepository.findById(id);
        return supplier;
    }

    @Override
    public void create(Supplier supplier) {
        this.supplierRepository.save(supplier);
    }

    @Override
    public void update(Supplier supplier) {
        this.supplierRepository.save(supplier);
    }

    @Override
    public void delete(Supplier supplier) {
        this.supplierRepository.delete(supplier);
    }
}