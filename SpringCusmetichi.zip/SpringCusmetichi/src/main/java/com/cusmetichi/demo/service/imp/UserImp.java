package com.cusmetichi.demo.service.imp;

import com.cusmetichi.demo.entity.User;
import com.cusmetichi.demo.repository.UserRepository;
import com.cusmetichi.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class UserImp implements UserService {

    @Autowired
    private  UserRepository userRepository;


    @Override
    public List<User> findAll(){
        return userRepository.findAll();
    }

    @Override
    public User findById(int id) {
        User user = this.userRepository.findById(id);
        return user;
    }

    @Override
    public void create(User user) {
        this.userRepository.save(user);
    }

    @Override
    public void update(User user) {
        this.userRepository.save(user);
    }

    @Override
    public void delete(User user) {
        this.userRepository.delete(user);
    }
}