package com.cusmetichi.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CusmetichiApplicationTests {

	@Test
	void contextLoads() {
	}

}
